import fs from 'node:fs';
import path from 'node:path';

const BASE = 'http://127.0.0.1:8090/v1';
const MODEL = 'qwen36-35b-a3b';
const POSTS = path.resolve('everzone/posts');
const OUT = path.resolve('everzone/posts-zh');
const WORK = path.resolve('everzone/translate/_work_posts_zh');

const files = [
  [113, '113-택티컬-커맨더스-틸라노이드-아이템.md'],
  [114, '114-택티컬-커맨더스-자이안트-아이템.md'],
  [115, '115-택티컬-커맨더스-블레이더-아이템.md'],
  [116, '116-택티컬-커맨더스-팬텀-아이템.md'],
];

async function chat(prompt, maxTokens = 700) {
  const body = {
    model: MODEL,
    messages: [
      { role: 'system', content: '你是嚴謹的繁體中文遊戲文件審查員，只輸出指定格式。' },
      { role: 'user', content: prompt },
    ],
    temperature: 0,
    top_p: 1,
    max_tokens: maxTokens,
    stream: false,
  };
  const res = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(600000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const j = await res.json();
  return j.choices?.[0]?.message?.content ?? '';
}

const reports = [];
for (const [id, srcName] of files) {
  const src = fs.readFileSync(path.join(POSTS, srcName), 'utf8');
  const outFile = fs.readdirSync(OUT).find((f) => f.startsWith(id + '-') && f.endsWith('.md'));
  const out = fs.readFileSync(path.join(OUT, outFile), 'utf8');
  const prompt = `請比較韓國原文與繁體中文譯文，做最後的語意與可讀性審查。

已知並接受、不必再回報的項目：
- 「中文（韓文原名）」格式是刻意保留，括號內韓文不算殘留。
- 表格的欄數、列數、數字已用程式逐列驗證與原文一致。
- 全系列統一使用「道具」而非「裝備」。
- 原文的羅馬數字寫法（ll、lll、lV）是原始拼寫，譯文用 II/III/IV 是刻意修正。

只輸出以下三行，不要 JSON、不要 markdown、不要其他文字：
CONFIDENCE: <0-100 的整數>
VERDICT: <pass 或 needs_fix>
NOTES: <150 字以內，只列真正的語意錯誤、漏譯或明顯不通順；若無問題寫「無」>

=== 韓國原文 ===
${src}

=== 繁體中文譯文 ===
${out}`;
  console.log(`reviewing ${id}...`);
  const raw = await chat(prompt);
  const conf = raw.match(/CONFIDENCE:\s*(\d+)/i)?.[1];
  const verdict = raw.match(/VERDICT:\s*(pass|needs_fix)/i)?.[1];
  const notes = raw.match(/NOTES:\s*([\s\S]*)/i)?.[1]?.trim();
  if (!conf || !verdict) { console.log(raw); throw new Error(`bad format ${id}`); }
  reports.push({ id, file: outFile, confidence: Number(conf), verdict, notes });
  console.log(`  confidence=${conf} verdict=${verdict}`);
  console.log(`  ${notes}`);
}
fs.writeFileSync(path.join(WORK, 'qwen_review_113_116.json'), JSON.stringify(reports, null, 2), 'utf8');
