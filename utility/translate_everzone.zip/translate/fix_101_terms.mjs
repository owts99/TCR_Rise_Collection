import fs from 'node:fs';

const q = 'everzone/posts-zh/101-戰術指揮官-單位規格.md';
let t = fs.readFileSync(q, 'utf8');

const exact = [
  ['基礎生命值', '基礎體力'],
  ['浮空', '懸浮'],
  ['斯帕伊恩', '間諜'],
  ['代謝增幅器', '代謝強化'],
  ['掃視-II', '掃蕩觀測器-II'],
  ['掃視', '掃蕩觀測器'],
  ['星堡(奴役-III)', '星柱（奴役-III）'],
  ['星堡', '星柱'],
  ['EMP雷達槍', 'EMP鉛槍'],
  ['大端口-II', '巨大傳送-II'],
  ['大端口', '巨大傳送'],
  ['發光增幅器', '輝光推進器'],
  ['機械增幅器', '機械強化'],
  ['速度增幅器', '速度推進器'],
  ['震波線', '地震火焰'],
  ['迷彩偽裝', '偽裝潛伏'],
  ['地毯浮空(浮動)', '地毯浮游'],
  ['星彈, 叮噹星彈, 月彈, 扣子彈', '星殼、叮噹星殼、月神殼、彗星殼'],
  ['電磁偵測', '隱形偵測'],
  ['護盾流', '防護幕類'],
  ['達瑪', '多瑪'],
  ['E-便攜式', 'E-可攜'],
  ['能量傳輸-II', '能源轉移-II'],
  ['黑暗隱形(隱形-III)', '黑暗隱身（隱身-III）'],
  ['- MCD EMP', '- MCD 安瓿'],
  ['- UCD EMP', '- UCD 安瓿'],
];
for (const [from, to] of exact) t = t.split(from).join(to);

// standalone EMP (앰플) in ability lists -> 安瓿
t = t.replace(/(?<=[,、\s])EMP(?=[,、\s])/g, '安瓿');

fs.writeFileSync(q, t, 'utf8');
console.log('fixed 101');
