import fs from 'node:fs';
import path from 'node:path';

const POSTS = path.resolve('everzone/posts');
const OUT = path.resolve('everzone/posts-zh');

const files = [
  [106, '106-택티컬-커맨더스-바즈노이드-아이템.md'],
  [107, '107-택티컬-커맨더스-레일건너-아이템.md'],
  [108, '108-택티컬-커맨더스-GTA로켓런쳐-아이템.md'],
  [109, '109-택티컬-커맨더스-샤크-아이템.md'],
  [110, '110-택티컬-커맨더스-골리앗-아이템.md'],
  [111, '111-택티컬-커맨더스-트윈발칸-아이템.md'],
  [112, '112-택티컬-커맨더스-엑소노이드-아이템.md'],
  [113, '113-택티컬-커맨더스-틸라노이드-아이템.md'],
  [114, '114-택티컬-커맨더스-자이안트-아이템.md'],
  [115, '115-택티컬-커맨더스-블레이더-아이템.md'],
  [116, '116-택티컬-커맨더스-팬텀-아이템.md'],
];

function bodyOf(text) {
  const m = text.match(/^---\r?\n[\s\S]*?\r?\n---\r?\n/);
  if (!m) return null;
  return text.slice(m[0].length);
}

function tablesOf(body) {
  const blocks = [];
  let cur = null;
  for (const line of body.split('\n')) {
    if (line.trim().startsWith('|')) {
      if (!cur) { cur = []; blocks.push(cur); }
      cur.push(line);
    } else cur = null;
  }
  return blocks;
}

const split = (line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((s) => s.trim());
const nums = (s) => s.match(/\d+(?:\.\d+)?/g) ?? [];
const hangulOutside = (s) => /[\uAC00-\uD7A3]/.test(s.replace(/（[^）]*）/g, ''));

const errors = [];
for (const [id, srcName] of files) {
  const src = fs.readFileSync(path.join(POSTS, srcName), 'utf8');
  const outFile = fs.readdirSync(OUT).find((f) => f.startsWith(id + '-') && f.endsWith('.md'));
  if (!outFile) { errors.push(`${id}: output missing`); continue; }
  const out = fs.readFileSync(path.join(OUT, outFile), 'utf8');
  const sBody = bodyOf(src);
  const oBody = bodyOf(out);
  if (!oBody) { errors.push(`${id}: bad frontmatter`); continue; }
  if (out.includes('\uFFFD')) errors.push(`${id}: U+FFFD`);

  const sTables = tablesOf(sBody);
  const oTables = tablesOf(oBody);
  if (sTables.length !== oTables.length) {
    errors.push(`${id}: tables ${sTables.length} vs ${oTables.length}`);
    continue;
  }
  let rows = 0;
  for (let t = 0; t < sTables.length; t++) {
    const s = sTables[t];
    const o = oTables[t];
    if (s.length !== o.length) {
      errors.push(`${id} table${t}: rows ${s.length} vs ${o.length}`);
      continue;
    }
    if (split(s[0]).length !== split(o[0]).length) errors.push(`${id} table${t}: header cols`);
    const hc = split(o[0]).length;
    for (let r = 0; r < o.length; r++) {
      if (split(o[r]).length !== hc) errors.push(`${id} table${t} line${r}: row cols ${split(o[r]).length} != header ${hc}`);
    }
    for (let r = 2; r < s.length; r++) {
      rows++;
      const sc = split(s[r]);
      const oc = split(o[r]);
      if (sc.length !== oc.length) {
        errors.push(`${id} table${t} row${r}: cols ${sc.length} vs ${oc.length}`);
        continue;
      }
      const scData = sc.slice(1).join(' ');
      const ocData = oc.slice(1).join(' ');
      if (nums(scData).join(',') !== nums(ocData).join(',')) {
        errors.push(`${id} table${t} row${r}: numbers [${nums(scData)}] vs [${nums(ocData)}]`);
      }
      if (hangulOutside(oc[0])) errors.push(`${id} table${t} row${r}: raw Hangul "${oc[0]}"`);
    }
  }
  console.log(`${id}: ${sTables.length} tables, ${rows} data rows`);

  const sHeads = (sBody.match(/^#{1,3} .+$/gm) ?? []).length;
  const oHeads = (oBody.match(/^#{1,3} .+$/gm) ?? []).length;
  if (sHeads !== oHeads) errors.push(`${id}: headings ${sHeads} vs ${oHeads}`);

  let h = 0;
  for (const line of oBody.split('\n')) if (hangulOutside(line)) { h++; if (h <= 5) errors.push(`${id}: Hangul outside: ${line.slice(0, 100)}`); }
}

if (errors.length) {
  console.log(`\nERRORS (${errors.length}):\n` + errors.join('\n'));
  process.exit(1);
}
console.log('\nALL 106-109 CHECKS PASSED');
