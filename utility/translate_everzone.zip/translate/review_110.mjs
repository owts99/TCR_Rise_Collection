import fs from 'node:fs';
import path from 'node:path';

const BASE = 'http://127.0.0.1:8090/v1';
const MODEL = 'qwen36-35b-a3b';
const src = fs.readFileSync(path.resolve('everzone/posts/110-택티컬-커맨더스-골리앗-아이템.md'), 'utf8');
const out = fs.readFileSync(path.resolve('everzone/posts-zh/110-戰術指揮官-哥利亞道具.md'), 'utf8');

const prompt = `請比較韓國原文與繁體中文譯文，做最後的語意與可讀性審查。

已知並接受、不必再回報的項目：
- 「中文（韓文原名）」格式是刻意保留，括號內韓文不算殘留。
- 表格的欄數、列數、數字已用程式逐列驗證與原文一致。
- 原文的 폴라리스ll / lll / lV 是原始拼寫，譯文用 II/III/IV 是刻意修正。

只輸出以下三行，不要 JSON、不要 markdown、不要其他文字：
CONFIDENCE: <0-100 的整數>
VERDICT: <pass 或 needs_fix>
NOTES: <150 字以內，只列真正的語意錯誤、漏譯或明顯不通順；若無問題寫「無」>

=== 韓國原文 ===
${src}

=== 繁體中文譯文 ===
${out}`;

const body = {
  model: MODEL,
  messages: [
    { role: 'system', content: '你是嚴謹的繁體中文遊戲文件審查員，只輸出指定格式。' },
    { role: 'user', content: prompt },
  ],
  temperature: 0,
  top_p: 1,
  max_tokens: 700,
  stream: false,
};
const res = await fetch(`${BASE}/chat/completions`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify(body),
  signal: AbortSignal.timeout(600000),
});
if (!res.ok) throw new Error(`HTTP ${res.status}`);
const j = await res.json();
console.log(j.choices?.[0]?.message?.content ?? '');
