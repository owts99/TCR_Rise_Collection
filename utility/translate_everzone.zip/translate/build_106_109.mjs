import fs from 'node:fs';
import path from 'node:path';

const POSTS = path.resolve('everzone/posts');
const OUT = path.resolve('everzone/posts-zh');
const WORK = path.resolve('everzone/translate/_work_posts_zh');

const rawMap = JSON.parse(fs.readFileSync(path.join(WORK, 'name_map_106_109.json'), 'utf8'));
const corrections = {
  '레비테이트': '懸浮',
  '파어웨이건': '遠距槍',
  '리드빔건': '引導光束槍',
  '레이저유크릭건': '雷射衝擊槍',
  '레이저엑트렉터': '雷射抽取器',
  '플라스티마': '電漿體',
  'X-GT로켓런쳐': 'X-GT 火箭筒',
  '프랙로켓런쳐': '破片火箭筒',
  '히트로켓런쳐': '熱能火箭筒',
  '엑스터': '艾克斯特',
  '트윈스니퍼': '雙聯狙擊槍',
  '로드레이저': '軌道雷射',
  '발리스타': '弩砲',
  '울트레일': '終極軌道',
  '블러드레일': '血軌',
  '카펫플로팅': '地毯浮游',
  'UCD앰플': 'UCD 安瓿',
  'MCD앰플': 'MCD 安瓿',
  'UCD 앰플': 'UCD 安瓿',
  'MCD 앰플': 'MCD 安瓿',
  'MK-Ⅰ어썰트건': 'MK-Ⅰ 突擊槍',
  'MK-Ⅱ어썰트건': 'MK-Ⅱ 突擊槍',
  'MK-Ⅲ어썰트건': 'MK-Ⅲ 突擊槍',
  'MK-Ⅳ어썰트건': 'MK-Ⅳ 突擊槍',
  'MK-Ⅴ어썰트건': 'MK-Ⅴ 突擊槍',
  'MK-Ⅵ어썰트건': 'MK-Ⅵ 突擊槍',
  '폴라리스ll': '北極星 II',
  '폴라리스lll': '北極星 III',
  '폴라리스lV': '北極星 IV',
  '폴라리스V': '北極星 V',
  'GT로켓런쳐': 'GT 火箭筒',
  'GX로켓런쳐': 'GX 火箭筒',
  'ATA로켓런쳐': 'ATA 火箭筒',
  'ACS로켓런쳐': 'ACS 火箭筒',
  'AGA로켓런쳐': 'AGA 火箭筒',
  'ASA로켓런쳐': 'ASA 火箭筒',
  'GM로켓런쳐': 'GM 火箭筒',
  '두키로켓런쳐': '杜基火箭筒',
  'SCA라이플': 'SCA 步槍',
  'ACV라이플': 'ACV 步槍',
};
const nameMap = { ...rawMap, ...corrections };

const headerMap = {
  '아이템이름': '道具名稱',
  '무기이름': '武器名稱',
  '발사체': '發射體',
  '테크레벨': '科技等級',
  '에너지소모량': '能量消耗',
  '설명': '說明',
  '공격력': '攻擊力',
  '사정거리': '射程',
  '연사속도': '連射速度',
  '공격모드': '攻擊模式',
  '무기타입': '武器類型',
  '에너지소비': '能量消耗',
  '복잡도/무게/공간': '複雜度/重量/空間',
};

const valueMap = {
  '지상전용': '僅對地',
  '지상/대공': '地空',
  '대공전용': '僅對空',
  '대공': '對空',
  '일반미사일': '一般飛彈',
  '총기류': '槍械類',
  '레이저형': '雷射型',
  '좌우미사일': '左右飛彈',
  '인간형 유닛 치료': '治療人類型單位',
  '기계형 유닛 치료': '治療機械型單位',
  '투명해짐': '隱形',
  '발자국을 남기지 않음': '不留腳印',
  '적 유닛의 체력을 공격': '攻擊敵方單位體力',
  '적의 유닛의 에너지를 공격': '攻擊敵方單位能量',
  '부양': '懸浮',
  '막강한 핵 미사일(리플레이 채팅에 데미지 1500 확인)': '威力強大的核飛彈（重播聊天中確認傷害 1500）',
  'GTA로켓런쳐가 발사한 핵을 막을 때 사용': '用於攔截 GTA 火箭筒發射的核彈',
};

const textMap = {
  '- [(index) 택티컬 커맨더스 유닛 스펙 링크](https://everzone.tistory.com/101)': '- [(index) 戰術指揮官單位規格連結](https://everzone.tistory.com/101)',
  '- [(index) 택티컬 커맨더 유닛 스펙 링크](https://everzone.tistory.com/101)': '- [(index) 戰術指揮官單位規格連結](https://everzone.tistory.com/101)',

  '# 택티컬 커맨더스 바즈노이드 아이템': '# 戰術指揮官 巴茲尼德道具',
  '# 바즈노이드 무기 및 기술': '# 巴茲尼德武器與技術',
  '바즈노이드는 휴머노이드의 업그레이드 형으로 휴머노이드와 레일건너중 가장 느리지만 사정거리가 긴 롱레인지건을 사용할 수 있으며 장갑도 보다 단단합니다. 틸라노이드하고 비슷하나, 공중 공격이 불가능합니다.':
    '巴茲尼德是 Humanoid 的升級型，在 Humanoid 與 Railgunner 中速度最慢，但能使用射程較長的長程槍，裝甲也更堅固。與 Tilanoid 相似，但無法進行空中攻擊。',
  '- 기본체력: 2000, 600(초기버전)': '- 基礎體力：2000，600（初期版本）',
  '- 기본공간: 80': '- 基礎空間：80',
  '- 기본무게: 90': '- 基礎重量：90',

  '# 택티컬 커맨더스 레일건너 아이템': '# 戰術指揮官 軌道砲手道具',
  '# 레일건너 무기 및 기술': '# 軌道砲手武器與技術',
  '레일건너는 휴머노이드와 비슷한 인간형 유닛으로, 휴머노이드와 비교할 때 기본 장갑이 좀더 우수하며 속도와 레벨업이 느린 편입니다. 수류탄이라는 분산공격형 특수 아이템을 사용할 수 있습니다.':
    'Railgunner 是與 Humanoid 相似的人型單位；相較 Humanoid，基礎裝甲略優，但速度與升級較慢。可使用「手榴彈」這種分散攻擊型特殊道具。',
  '- 기본체력: 1800, 250(초기버전)': '- 基礎體力：1800，250（初期版本）',
  '- 기본무게: 80': '- 基礎重量：80',
  '- 팬텀 무기와 같음': '- 與 Phantom 武器相同',

  '# 택티컬 커맨더스 GTA로켓런쳐 아이템': '# 戰術指揮官 GTA 火箭筒道具',
  '# GTA로켓런쳐 무기 및 기술': '# GTA 火箭筒武器與技術',
  '미사일을 기본으로 장착하는 유닛으로 대공공격에 적당합니다. 기본적인 시야가 넓고 레벨업도 빠른 편입니다. 기본 장갑력도 갖춰져서 맷집도 있는 편이며, 로켓런쳐가 갖고 있는 I.C.B.M(핵)은 전쟁중에 깨끗한 뒤집기의 묘미를 선사합니다.':
    '以飛彈為基礎裝備的單位，適合對空攻擊。基礎視野較廣，升級也較快。本身具備基礎裝甲，因此相當耐打；其搭載的 I.C.B.M（核彈）能在戰爭中帶來「乾淨翻盤」的樂趣。',
  '- 기본체력: 1300, 200(초기버전)': '- 基礎體力：1300，200（初期版本）',
  '- 기본공간: 90': '- 基礎空間：90',

  '# 택티컬 커맨더스 샤크 아이템': '# 戰術指揮官 鯊魚道具',
  '# 샤크 무기 및 기술': '# 鯊魚武器與技術',
  '대공능력에 적합한 유닛으로 시야도 넓습니다. 단점이 있다면 속도가 느린 편이고 레벨업이 어렵다는 것입니다. 그러나 기본 장갑이 있어서 전투 중에도 쉽게 부서지지 않습니다.':
    '適合對空作戰的單位，視野也廣。缺點是速度較慢、升級較困難，但因為有基礎裝甲，戰鬥中不容易被擊毀。',
  '- 기본체력: 1650, 350(초기버전)': '- 基礎體力：1650，350（初期版本）',
  '- 기본무게: 100': '- 基礎重量：100',
  '- 듀크 무기와 같음': '- 與 Duke 武器相同',

  '## 특수아이템': '## 特殊道具',
  '## 무기 목록': '## 武器列表',
  '## 리플레이 자료로 확인된 값': '## 由重播資料確認的數值',
};

const files = [
  { id: 106, src: '106-택티컬-커맨더스-바즈노이드-아이템.md', out: '106-戰術指揮官-巴茲尼德道具.md', title: '戰術指揮官 巴茲尼德道具' },
  { id: 107, src: '107-택티컬-커맨더스-레일건너-아이템.md', out: '107-戰術指揮官-軌道砲手道具.md', title: '戰術指揮官 軌道砲手道具' },
  { id: 108, src: '108-택티컬-커맨더스-GTA로켓런쳐-아이템.md', out: '108-戰術指揮官-GTA火箭筒道具.md', title: '戰術指揮官 GTA 火箭筒道具' },
  { id: 109, src: '109-택티컬-커맨더스-샤크-아이템.md', out: '109-戰術指揮官-鯊魚道具.md', title: '戰術指揮官 鯊魚道具' },
];

const hasHangul = (s) => /[\uAC00-\uD7A3]/.test(s);
const splitCells = (line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((s) => s.trim());
const displayName = (src) => (hasHangul(src) && nameMap[src] ? `${nameMap[src]}（${src}）` : src);

function tableBlocks(lines) {
  const blocks = [];
  let cur = null;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith('|')) {
      if (!cur) { cur = { start: i, lines: [] }; blocks.push(cur); }
      cur.lines.push(lines[i]);
    } else cur = null;
  }
  return blocks;
}

function rebuildTable(block) {
  const rows = block.lines;
  const header = splitCells(rows[0]).map((c) => headerMap[c] ?? c);
  const n = header.length;
  const out = [`| ${header.join(' | ')} |`, `| ${Array(n).fill('---').join(' | ')} |`];
  for (const row of rows.slice(2)) {
    const cells = splitCells(row);
    if (cells.length !== n) throw new Error(`column mismatch: ${row}`);
    cells[0] = displayName(cells[0]);
    for (let i = 1; i < cells.length; i++) if (valueMap[cells[i]]) cells[i] = valueMap[cells[i]];
    out.push(`| ${cells.join(' | ')} |`);
  }
  return out;
}

for (const f of files) {
  const src = fs.readFileSync(path.join(POSTS, f.src), 'utf8').replace(/^\ufeff/, '');
  const fmEnd = src.indexOf('\n---', 4);
  const fm = src.slice(4, fmEnd);
  const body = src.slice(fmEnd + 4);
  const lines = body.split('\n');
  const blocks = tableBlocks(lines);
  const rebuilt = blocks.map(rebuildTable);

  const outLines = [];
  let bi = 0;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith('|')) {
      if (bi < blocks.length && i === blocks[bi].start) {
        outLines.push(...rebuilt[bi]);
        bi++;
      }
      continue;
    }
    const t = lines[i].trim();
    outLines.push(textMap[t] ?? lines[i]);
  }

  const fmLines = fm
    .split('\n')
    .map((l) => (l.startsWith('title:') ? `title: "${f.title}"` : l.startsWith('category:') ? 'category: "戰術指揮官"' : l))
    .concat(['lang: zh-TW', 'translated_by: "Spark-X2.5-4B"']);

  fs.writeFileSync(path.join(OUT, f.out), `---\n${fmLines.join('\n')}\n---\n${outLines.join('\n')}\n`, 'utf8');
  console.log(`${f.out}: ${rebuilt.length} tables`);
}
