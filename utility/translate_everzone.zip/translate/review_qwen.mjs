import fs from 'node:fs';
import path from 'node:path';

const BASE = 'http://127.0.0.1:8090/v1';
const MODEL = 'qwen36-35b-a3b';
const POSTS = path.resolve('everzone/posts');
const OUT = path.resolve('everzone/posts-zh');
const WORK = path.resolve('everzone/translate/_work_posts_zh');

const files = [
  [102, '102-택티컬-커맨더스-인간-유닛-공통-아이템.md'],
  [103, '103-택티컬-커맨더스-차량-유닛-공통-아이템.md'],
  [104, '104-택티컬-커맨더스-비행-유닛-공통-아이템.md'],
];

async function chat(prompt, maxTokens = 3000) {
  const body = {
    model: MODEL,
    messages: [
      { role: 'system', content: '你是嚴謹的繁體中文遊戲文件審查員，只輸出 JSON。' },
      { role: 'user', content: prompt },
    ],
    temperature: 0,
    top_p: 1,
    max_tokens: maxTokens,
    stream: false,
  };
  const res = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(600000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${(await res.text()).slice(0, 300)}`);
  const j = await res.json();
  return j.choices?.[0]?.message?.content ?? '';
}

function parseJson(text) {
  const cleaned = text.replace(/^\s*```(?:json)?\s*/i, '').replace(/\s*```\s*$/i, '').trim();
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start < 0 || end < 0) throw new Error(`no JSON: ${cleaned.slice(0, 200)}`);
  return JSON.parse(cleaned.slice(start, end + 1));
}

const reports = [];
for (const [id, srcName] of files) {
  const src = fs.readFileSync(path.join(POSTS, srcName), 'utf8');
  const outFile = fs.readdirSync(OUT).find((f) => f.startsWith(id + '-') && f.endsWith('.md'));
  const out = fs.readFileSync(path.join(OUT, outFile), 'utf8');

  const prompt = `請比較以下韓國原文與繁體中文譯文，做一次快速但嚴格的審查。

評分重點：
1. 內容完整性：有沒有漏掉段落、表格列、註解。
2. 表格結構：欄數、列數、數字、單位是否與原文一致。
3. 術語與名稱：同一裝備/單位是否前後一致，中文是否可理解。
4. 繁體中文（台灣用語）可讀性。
5. 韓文殘留：括號內的韓文原名可接受，括號外不應有韓文。

請給 0–100 的信任分（confidence），以及 verdict（pass 或 needs_fix）。只要發現會影響閱讀或資料正確性的問題，就給 needs_fix。
輸出純 JSON，不要 code fence，格式：
{"confidence":0,"verdict":"pass","issues":[{"severity":"high|medium|low","location":"行號或段落","problem":"...","suggestion":"..."}],"summary":"..."}

=== 韓國原文 ===
${src}

=== 繁體中文譯文 ===
${out}`;

  console.log(`reviewing ${id}...`);
  let raw = '';
  let parsed = null;
  for (let attempt = 1; attempt <= 3; attempt++) {
    raw = await chat(prompt);
    try {
      parsed = parseJson(raw);
      break;
    } catch (e) {
      console.log(`  parse failed attempt ${attempt}: ${e.message}`);
    }
  }
  if (!parsed) {
    console.log(raw.slice(0, 500));
    throw new Error(`could not parse review for ${id}`);
  }
  reports.push({ id, file: outFile, ...parsed });
  console.log(`  confidence=${parsed.confidence} verdict=${parsed.verdict} issues=${parsed.issues?.length ?? 0}`);
}

fs.writeFileSync(path.join(WORK, 'qwen_review.json'), JSON.stringify(reports, null, 2), 'utf8');
console.log('\n' + JSON.stringify(reports, null, 2));
