import fs from 'node:fs';
import path from 'node:path';

const BASE = 'http://127.0.0.1:8090/v1';
const MODEL = 'Spark-X2.5-4B';
const POSTS = path.resolve('everzone/posts');
const OUT = path.resolve('everzone/posts-zh');
const WORK = path.resolve('everzone/translate/_work_posts_zh');

const files = [
  {
    id: 102,
    src: '102-택티컬-커맨더스-인간-유닛-공통-아이템.md',
    out: '102-戰術指揮官-人類單位共通道具.md',
    title: '戰術指揮官 人類單位共通道具',
  },
  {
    id: 103,
    src: '103-택티컬-커맨더스-차량-유닛-공통-아이템.md',
    out: '103-戰術指揮官-車輛單位共通道具.md',
    title: '戰術指揮官 車輛單位共通道具',
  },
  {
    id: 104,
    src: '104-택티컬-커맨더스-비행-유닛-공통-아이템.md',
    out: '104-戰術指揮官-飛行單位共通道具.md',
    title: '戰術指揮官 飛行單位共通道具',
  },
];

const GLOSSARY = `
택티컬 커맨더스=戰術指揮官
인간유닛=人類單位
차량유닛=車輛單位
비행유닛=飛行單位
전차유닛=戰車單位
보병=步兵
전차=戰車
센서=感測器
엔진=引擎
장갑=裝甲
컴퓨터=電腦
파워=動力
정보=資訊
참고사항=參考事項
테크레벨=科技等級
시야거리=視野距離
에너지소모량=能量消耗
에너지 소모량=能量消耗
타입=類型
출력=輸出
복잡도=複雜度
무게=重量
공간=空間
보너스체력=額外體力
최대복잡도=最大複雜度
보너스 경험치=額外經驗值
최대에너지=最大能量
에너지재생률=能量再生率
저항력=抗性
체력=體力
방향성=方向性
전방향=全向
재충전(O)=可充電(O)
비재충전(X)=不可充電(X)
일반 장갑=一般裝甲
Pluto 에이리언 행성=Pluto 外星行星
총기=槍械
레이저=雷射
미사일=飛彈
총기,레이저=槍械、雷射
총기,미사일=槍械、飛彈
레이저,미사일=雷射、飛彈
업그레이드 가능한 장갑=可升級裝甲
`.trim();

function splitSections(body) {
  const lines = body.split('\n');
  const chunks = [];
  let cur = [];
  for (const line of lines) {
    if (/^#{1,2} /.test(line) && cur.length) {
      chunks.push(cur.join('\n').trim());
      cur = [line];
    } else {
      cur.push(line);
    }
  }
  if (cur.length) chunks.push(cur.join('\n').trim());
  return chunks.filter(Boolean);
}

function promptFor(text) {
  return `你是專業韓→繁中（台灣）遊戲文件翻譯。只輸出翻譯後的 Markdown，不要說明、不要 code fence。

規則：
1. 保留標題層級、空行、表格的管線與分隔列；表格列數與欄數不可改變。
2. 所有數字、單位（kj、kg、m、m/s）、英文縮寫、O/X、問號原樣保留。
3. 不要合併或拆分表格列；不要新增原文沒有的內容；不要省略任何一列。
4. 裝備、零件、單位等專有名詞用「中文（韓文原文）」格式，例如：비쥬얼센서 → 視覺感測器（비쥬얼센서）。
5. 同一篇內同一名稱必須使用相同譯名；不確定的名稱用合理音譯。
6. 連結的 URL 不要翻譯，只翻譯連結文字。
7. 語氣用台灣繁體中文，規格表用精簡名詞。

術語表（必須遵守）：
${GLOSSARY}

原文：
${text}`;
}

async function chat(messages, maxTokens = 7000, temperature = 0) {
  const body = {
    model: MODEL,
    messages,
    temperature,
    top_p: 1,
    max_tokens: maxTokens,
    stream: false,
  };
  const res = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(600000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${(await res.text()).slice(0, 300)}`);
  const j = await res.json();
  return { text: j.choices?.[0]?.message?.content ?? '', usage: j.usage ?? {} };
}

function clean(text) {
  return text
    .replace(/^\s*```(?:markdown|md)?\s*/i, '')
    .replace(/\s*```\s*$/i, '')
    .trim();
}

async function translate(text) {
  let last = '';
  for (let attempt = 1; attempt <= 3; attempt++) {
    const { text: raw, usage } = await chat(
      [
        { role: 'system', content: '你是專業遊戲文件翻譯，只輸出翻譯後的 Markdown。' },
        { role: 'user', content: promptFor(text) },
      ],
      7000,
      attempt === 1 ? 0 : 0.2,
    );
    last = clean(raw);
    const bad = last.includes('\uFFFD');
    console.log(`  attempt ${attempt}: ${last.length} chars, tok=${usage.prompt_tokens}/${usage.completion_tokens}${bad ? ' [U+FFFD]' : ''}`);
    if (last.length > 20 && !bad) return last;
  }
  return last;
}

fs.mkdirSync(OUT, { recursive: true });
fs.mkdirSync(WORK, { recursive: true });

for (const f of files) {
  const raw = fs.readFileSync(path.join(POSTS, f.src), 'utf8').replace(/^\ufeff/, '');
  const m = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n/);
  if (!m) throw new Error(`no frontmatter: ${f.src}`);
  const fm = m[1];
  const body = raw.slice(m[0].length);
  const sections = splitSections(body);
  console.log(`\n${f.id}: ${sections.length} sections`);

  const dir = path.join(WORK, String(f.id));
  fs.mkdirSync(dir, { recursive: true });

  const translated = [];
  for (let i = 0; i < sections.length; i++) {
    const cache = path.join(dir, `${String(i).padStart(2, '0')}.md`);
    if (fs.existsSync(cache)) {
      const cached = fs.readFileSync(cache, 'utf8').trim();
      if (cached) {
        console.log(`  [${i + 1}/${sections.length}] cached ${cached.length} chars`);
        translated.push(cached);
        continue;
      }
    }
    console.log(`  [${i + 1}/${sections.length}] ${sections[i].split('\n')[0].slice(0, 60)}`);
    const out = await translate(sections[i]);
    fs.writeFileSync(cache, out + '\n', 'utf8');
    translated.push(out);
  }

  const outFm = fm
    .split(/\r?\n/)
    .map((line) => {
      if (/^title:/.test(line)) return `title: "${f.title}"`;
      if (/^category:/.test(line)) return 'category: "戰術指揮官"';
      return line;
    })
    .concat(['lang: zh-TW', `translated_by: "${MODEL}"`])
    .join('\n');

  const output = `---\n${outFm}\n---\n\n${translated.join('\n\n')}\n`;
  fs.writeFileSync(path.join(OUT, f.out), output, 'utf8');
  console.log(`  wrote ${f.out}: ${output.length} chars, ${output.split('\n').length} lines`);
}
