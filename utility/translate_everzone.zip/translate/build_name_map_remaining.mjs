import fs from 'node:fs';
import path from 'node:path';

const BASE = 'http://127.0.0.1:8090/v1';
const MODEL = 'qwen36-35b-a3b';
const WORK = path.resolve('everzone/translate/_work_posts_zh');

const names = fs.readFileSync(path.join(WORK, 'remaining_names.txt'), 'utf8')
  .split('\n').map((s) => s.trim()).filter(Boolean);
console.log(`names: ${names.length}`);

async function chat(prompt, maxTokens) {
  const body = {
    model: MODEL,
    messages: [
      { role: 'system', content: '你是遊戲在地化譯者，只輸出 TSV，不要說明。' },
      { role: 'user', content: prompt },
    ],
    temperature: 0,
    top_p: 1,
    max_tokens: maxTokens,
    stream: false,
  };
  const res = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(900000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const j = await res.json();
  return j.choices?.[0]?.message?.content ?? '';
}

const promptFor = (chunk) => `你是遊戲在地化譯者。把以下韓國遊戲《Tactical Commanders》的裝備、道具、武器名稱翻成台灣繁體中文。
只輸出「韓文原名<TAB>中文譯名」，一行一筆，不要編號、不要說明、不要 code fence。

規則：
- 名稱要像遊戲道具/武器名，2–12 個字為主，不要保留韓文。
- 同一系列用相同前綴；後綴：건=槍、런쳐=火箭筒、미사일=飛彈、라이플=步槍、머신건=機槍、캐논=加農砲、소드=劍、세이버=軍刀、너클=指虎、피스트=拳、쉘=殼、앰플=安瓿、부스터=推進器、디바이스=裝置。
- 原廠代號（A1/A2、MK-、GT、GX、ATA、ACS、AGA、ASA、EMP、SDI、ICBM 等）保留。
- 原文含英文括號時，譯名也保留該英文，例如 플레임-I (FLAME-I) → 火焰-I（FLAME-I）。
- 不要加多餘括號。

名稱：
${chunk.join('\n')}`;

const map = {};
for (let i = 0; i < names.length; i += 50) {
  const chunk = names.slice(i, i + 50);
  console.log(`batch ${i / 50 + 1}: ${chunk.length}`);
  let text = '';
  for (let attempt = 1; attempt <= 3; attempt++) {
    text = await chat(promptFor(chunk), 3500);
    const got = chunk.filter((n) => text.includes(n + '\t'));
    console.log(`  attempt ${attempt}: ${got.length}/${chunk.length}`);
    if (got.length === chunk.length) break;
  }
  for (const line of text.split('\n')) {
    const m = line.match(/^([^\t]+)\t(.+)$/);
    if (!m) continue;
    const ko = m[1].trim();
    const zh = m[2].trim();
    if (names.includes(ko) && !map[ko]) map[ko] = zh;
  }
}

const missing = names.filter((n) => !map[n]);
console.log(`mapped ${Object.keys(map).length}/${names.length}, missing ${missing.length}`);
if (missing.length) console.log('MISSING:\n' + missing.join('\n'));
fs.writeFileSync(path.join(WORK, 'name_map_remaining.json'), JSON.stringify(map, null, 2), 'utf8');
fs.writeFileSync(path.join(WORK, 'name_map_remaining.tsv'), names.map((n) => `${n}\t${map[n] ?? ''}`).join('\n') + '\n', 'utf8');
