import fs from 'node:fs';
import path from 'node:path';

const BASE = 'http://127.0.0.1:8090/v1';
const MODEL = 'qwen36-35b-a3b';
const WORK = path.resolve('everzone/translate/_work_posts_zh');
const values = fs.readFileSync(path.join(WORK, 'remaining_values.txt'), 'utf8')
  .split('\n').map((s) => s.trim()).filter(Boolean);
console.log(`values: ${values.length}`);

async function chat(prompt, maxTokens = 3000) {
  const body = {
    model: MODEL,
    messages: [
      { role: 'system', content: '你是遊戲文件翻譯，只輸出 TSV。' },
      { role: 'user', content: prompt },
    ],
    temperature: 0,
    top_p: 1,
    max_tokens: maxTokens,
    stream: false,
  };
  const res = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(900000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const j = await res.json();
  return j.choices?.[0]?.message?.content ?? '';
}

const prompt = `把以下韓國遊戲表格中的欄位值與說明翻成台灣繁體中文。
只輸出「原文<TAB>譯文」，一行一筆，不要說明、不要 code fence。
保留數字、O/X、括號、英文代號；表格欄位名照常見譯法（테크레벨=科技等級、공격력=攻擊力、사정거리=射程、연사속도=連射速度、공격모드=攻擊模式、무기타입=武器類型、에너지소비=能量消耗、설명=說明、복잡도/무게/공간=複雜度/重量/空間、에너지소모량=能量消耗）。
說明句要自然、精簡，不要加句號以外的內容。

${values.join('\n')}`;

const text = await chat(prompt, 5000);
const map = {};
for (const line of text.split('\n')) {
  const m = line.match(/^([^\t]+)\t(.+)$/);
  if (m) map[m[1].trim()] = m[2].trim();
}
const missing = values.filter((v) => !map[v]);
console.log(`mapped ${Object.keys(map).length}/${values.length}, missing ${missing.length}`);
if (missing.length) console.log(missing.join('\n'));
fs.writeFileSync(path.join(WORK, 'value_map_remaining.json'), JSON.stringify(map, null, 2), 'utf8');
