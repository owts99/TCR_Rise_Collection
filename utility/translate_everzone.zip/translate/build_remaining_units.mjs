import fs from 'node:fs';
import path from 'node:path';

const POSTS = path.resolve('everzone/posts');
const OUT = path.resolve('everzone/posts-zh');
const WORK = path.resolve('everzone/translate/_work_posts_zh');

const maps = [
  JSON.parse(fs.readFileSync(path.join(WORK, 'name_map.json'), 'utf8')),
  JSON.parse(fs.readFileSync(path.join(WORK, 'name_map_106_109.json'), 'utf8')),
  JSON.parse(fs.readFileSync(path.join(WORK, 'name_map_remaining.json'), 'utf8')),
];
const corrections = {
  'UCD앰플': 'UCD 安瓿',
  'MCD앰플': 'MCD 安瓿',
  'UCD 앰플': 'UCD 安瓿',
  'MCD 앰플': 'MCD 安瓿',
  '아크로너스': '阿克隆諾斯',
  '슈밤(구자료)': '舒巴姆（舊資料）',
  '클락-EF': '時鐘-EF',
  '울티밋배리어-II': '終極屏障-II',
  'EX발칸포': 'EX 火神砲',
  'S-라이트아틸러리': 'S-輕型火砲',
  'K-라이트아틸러리': 'K-輕型火砲',
  'GA 블라스터': 'GA 爆能槍',
  'TK 블라스터': 'TK 爆能槍',
  '가드커튼-I': '防護幕-I',
  '가드커튼-II': '防護幕-II',
  'CK-10포': 'CK-10 砲',
  'CK-20포': 'CK-20 砲',
  'CK-30포': 'CK-30 砲',
  'CK-40포': 'CK-40 砲',
  'CK-50포': 'CK-50 砲',
  '리소스카고': '資源貨櫃',
  '라지리소스카고': '大型資源貨櫃',
  '에너지트랜스퍼': '能源轉移',
  '익스트랙카고': '萃取貨櫃',
  '레비테이트': '懸浮',
  '스파이온': '間諜',
  '마이크로힐': '微型治療',
  '타이밍필': '定時器',
  '메타볼릭부스터': '代謝強化',
  '메타볼릭부스터 II': '代謝強化 II',
  '캐틀링건': '加特林機槍',
  '플라스마캐틀링건': '電漿加特林機槍',
  '울티밋배리어': '終極屏障',
  '다이너마이트': '炸藥',
  '다이너마이트호러': '炸藥恐怖',
  '자폭장치': '自爆裝置',
  '힐제너레이터': '治療產生器',
  '벙커노이드': '碉堡型',
  '레인저': '遊騎兵',
  '리페어툴': '修理工具',
  '로보틱암': '機械臂',
  '텔리키네틱스': '念動力',
  '트랜스포터': '運輸器',
  '필드재네레이터': '場域產生器',
  '페이지제너레이터': '傳送門產生器',
  '쉴드제너레이터-Ⅰ': '護盾產生器-I',
  '쉴드제너레이터-Ⅱ': '護盾產生器-II',
  '쉴드제너레이터-Ⅲ': '護盾產生器-III',
};
const nameMap = Object.assign({}, ...maps, corrections);

const headerMap = {
  '아이템이름': '道具名稱', '무기이름': '武器名稱', '발사체': '發射體',
  '이름': '名稱', '테크레벨': '科技等級', '에너지소모량': '能量消耗',
  '에너지 소모량': '能量消耗', '에너지소비': '能量消耗', '설명': '說明',
  '공격력': '攻擊力', '사정거리': '射程', '연사속도': '連射速度',
  '공격모드': '攻擊模式', '무기타입': '武器類型', '복잡도/무게/공간': '複雜度/重量/空間',
  '시야거리': '視野距離', '타입': '類型', '보너스체력': '額外體力',
  '장갑': '裝甲', '최대복잡도': '最大複雜度', '보너스 경험치': '額外經驗值',
  '최대에너지': '最大能量', '에너지재생률': '能量再生率', '저항력': '抗性',
  '체력': '體力', '출력': '輸出', '복잡도': '複雜度', '무게': '重量', '공간': '空間',
  '유닛이름': '單位名稱', '기본체력': '基礎體力', '기본장갑': '基礎裝甲',
  '이동속도': '移動速度', '업그레이드 출처': '升級來源', '업그레이드 지수': '升級指數',
  '특수능력': '特殊能力', '기능': '功能',
};

const baseValueMap = {
  '지상전용': '僅對地', '지상/대공': '地/空', '대공전용': '僅對空', '대공': '對空',
  '일반미사일': '一般飛彈', '총기류': '槍械類', '레이저형': '雷射型',
  '좌우미사일': '左右飛彈', '근접공격': '近戰攻擊', '방향성': '方向性', '전방향': '全向',
  '재충전(O)': '可充電(O)', '비재충전(X)': '不可充電(X)',
  '인간형 유닛 치료': '治療人類型單位', '기계형 유닛 치료': '治療機械型單位',
  '인간 유닛 치료': '治療人類型單位', '기계 유닛 치료': '治療機械型單位',
  '투명해짐': '隱形', '투명해진다': '隱形', '발자국을 남기지 않음': '不留腳印',
  '조명탄': '照明彈', '부양': '懸浮',
};
const remainingValues = JSON.parse(fs.readFileSync(path.join(WORK, 'value_map_remaining.json'), 'utf8'));
const valueMap = { ...remainingValues, ...baseValueMap };

const textFixes = [
  ['基本體力', '基礎體力'], ['基本空間', '基礎空間'], ['基本重量', '基礎重量'],
  ['基本佔用空間', '基礎空間'], ['透過重播資料確認', '由重播資料確認'],
  ['人形', '戰猿'], ['輕型加農炮坦克', '輕炮車'], ['懸浮突擊', '戰艦控甲者'],
  ['砲兵', '自走砲'], ['托爾', '突岩'], ['札納克', '占薩克'],
  ['Exorion', '艾洛比'], ['Elombre', '雷霆弩'], ['Aerofighter', '空戰機'],
  ['Fire Eagle', '火之鷹'], ['Orion', '獵戶座'], ['Executor', '空中判官'],
  ['費利烏斯', '支援者'], ['傑斯特', '熱忱'], ['醫官', '醫療兵'],
  ['修復師', '修理者'], ['治療生成器', '野戰醫院'], ['空投船', '運輸船'],
  ['空投艙', '運輸船'], ['炸彈小隊', '地雷兵'], ['遊騎兵', '生化兵'],
  ['雷達小隊', '搜尋者'], ['掃雷車', '清除兵'], ['堡壘諾伊德', '碉堡車'],
  ['根據 계도나후검 玩家的回報', '根據（계도나후검）玩家的回報'],
];

const proseLines = fs.readFileSync(path.join(WORK, 'remaining_prose.txt'), 'utf8')
  .split('\n').map((s) => s.trim()).filter(Boolean);
const textMap = JSON.parse(fs.readFileSync(path.join(WORK, 'text_map_remaining.json'), 'utf8'));
const lineToZh = new Map();
proseLines.forEach((line, i) => {
  const id = `L${String(i + 1).padStart(3, '0')}`;
  if (textMap[id]) lineToZh.set(line, textMap[id]);
});

function fixText(s) {
  for (const [from, to] of textFixes) s = s.split(from).join(to);
  return s;
}

const units = {
  105: ['105-택티컬-커맨더스-휴머노이드-아이템.md', '105-戰術指揮官-戰猿道具.md', '戰猿'],
  117: ['117-택티컬-커맨더스-스나이퍼-아이템.md', '117-戰術指揮官-狙擊手道具.md', '狙擊手'],
  118: ['118-택티컬-커맨더스-라이트캐논탱크-아이템.md', '118-戰術指揮官-輕炮車道具.md', '輕炮車'],
  119: ['119-택티컬-커맨더스-미디움탱크-아이템.md', '119-戰術指揮官-中戰車道具.md', '中戰車'],
  120: ['120-택티컬-커맨더스-헤비탱크-아이템.md', '120-戰術指揮官-重戰車道具.md', '重戰車'],
  121: ['121-택티컬-커맨더스-라이트바이크-아이템.md', '121-戰術指揮官-輕型摩托道具.md', '輕型摩托'],
  122: ['122-택티컬-커맨더스-호버레이드-아이템.md', '122-戰術指揮官-戰艦控甲者道具.md', '戰艦控甲者'],
  123: ['123-택티컬-커맨더스-아틸러리-아이템.md', '123-戰術指揮官-自走砲道具.md', '自走砲'],
  124: ['124-택티컬-커맨더스-토르-아이템.md', '124-戰術指揮官-突岩道具.md', '突岩'],
  125: ['125-택티컬-커맨더스-듀크-아이템.md', '125-戰術指揮官-公爵道具.md', '公爵'],
  126: ['126-택티컬-커맨더스-스푸키듀크-아이템.md', '126-戰術指揮官-幽靈公爵道具.md', '幽靈公爵'],
  127: ['127-택티컬-커맨더스-자낙-아이템.md', '127-戰術指揮官-占薩克道具.md', '占薩克'],
  128: ['128-택티컬-커맨더스-엑소리온-아이템.md', '128-戰術指揮官-艾洛比道具.md', '艾洛比'],
  129: ['129-택티컬-커맨더스-엘롬브레-아이템.md', '129-戰術指揮官-雷霆弩道具.md', '雷霆弩'],
  130: ['130-택티컬-커맨더스-에어로파이터-아이템.md', '130-戰術指揮官-空戰機道具.md', '空戰機'],
  131: ['131-택티컬-커맨더스-화이어이글-아이템.md', '131-戰術指揮官-火之鷹道具.md', '火之鷹'],
  132: ['132-택티컬-커맨더스-오리온-아이템.md', '132-戰術指揮官-獵戶座道具.md', '獵戶座'],
  133: ['133-택티컬-커맨더스-익스큐터-아이템.md', '133-戰術指揮官-空中判官道具.md', '空中判官'],
  134: ['134-택티컬-커맨더스-펠리우스-아이템.md', '134-戰術指揮官-支援者道具.md', '支援者'],
  135: ['135-택티컬-커맨더스-제스트-아이템.md', '135-戰術指揮官-熱忱道具.md', '熱忱'],
  136: ['136-택티컬-커맨더스-메딕-아이템.md', '136-戰術指揮官-醫療兵道具.md', '醫療兵'],
  137: ['137-택티컬-커맨더스-리페리어-아이템.md', '137-戰術指揮官-修理者道具.md', '修理者'],
  138: ['138-택티컬-커맨더스-힐제너레이터-아이템.md', '138-戰術指揮官-野戰醫院道具.md', '野戰醫院'],
  139: ['139-택티컬-커맨더스-드롭쉽-아이템.md', '139-戰術指揮官-運輸船道具.md', '運輸船'],
  140: ['140-택티컬-커맨더스-봄스쿼드-아이템.md', '140-戰術指揮官-地雷兵道具.md', '地雷兵'],
  141: ['141-택티컬-커맨더스-레인저-아이템.md', '141-戰術指揮官-生化兵道具.md', '生化兵'],
  142: ['142-택티컬-커맨더스-레이더스쿼드-아이템.md', '142-戰術指揮官-搜尋者道具.md', '搜尋者'],
  143: ['143-택티컬-커맨더스-스위퍼-아이템.md', '143-戰術指揮官-清除兵道具.md', '清除兵'],
  144: ['144-택티컬-커맨더스-이클립스-아이템.md', '144-戰術指揮官-日蝕道具.md', '日蝕'],
  145: ['145-택티컬-커맨더스-벙커노이드-아이템.md', '145-戰術指揮官-碉堡車道具.md', '碉堡車'],
};

const hasHangul = (s) => /[\uAC00-\uD7A3]/.test(s);
const splitCells = (line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((s) => s.trim());
const displayName = (src) => (hasHangul(src) && nameMap[src] ? `${nameMap[src]}（${src}）` : src);

function tableBlocks(lines) {
  const blocks = [];
  let cur = null;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith('|')) {
      if (!cur) { cur = { start: i, lines: [] }; blocks.push(cur); }
      cur.lines.push(lines[i]);
    } else cur = null;
  }
  return blocks;
}

function rebuildTable(block, file) {
  const rows = block.lines;
  const header = splitCells(rows[0]).map((c) => headerMap[c] ?? c);
  const n = header.length;
  const out = [`| ${header.join(' | ')} |`, `| ${Array(n).fill('---').join(' | ')} |`];
  for (const row of rows.slice(2)) {
    const cells = splitCells(row);
    if (cells.length !== n) throw new Error(`${file}: column mismatch: ${row}`);
    cells[0] = displayName(cells[0]);
    if (hasHangul(cells[0])) console.log(`UNKNOWN NAME ${file}: ${cells[0]}`);
    for (let i = 1; i < cells.length; i++) if (valueMap[cells[i]]) cells[i] = valueMap[cells[i]];
    out.push(`| ${cells.join(' | ')} |`);
  }
  return out;
}

for (const [id, [srcName, outName, unitName]] of Object.entries(units)) {
  const src = fs.readFileSync(path.join(POSTS, srcName), 'utf8').replace(/^\ufeff/, '');
  const fmEnd = src.indexOf('\n---', 4);
  const fm = src.slice(4, fmEnd);
  const body = src.slice(fmEnd + 4);
  const lines = body.split('\n');
  const blocks = tableBlocks(lines);
  const rebuilt = blocks.map((b) => rebuildTable(b, srcName));

  const outLines = [];
  let bi = 0;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith('|')) {
      if (bi < blocks.length && i === blocks[bi].start) {
        outLines.push(...rebuilt[bi]);
        bi++;
      }
      continue;
    }
    const t = lines[i].trim();
    let zh = lineToZh.get(t) ?? lines[i];
    zh = fixText(zh);
    if (t.startsWith('#')) {
      if (t.includes('택티컬 커맨더스')) zh = `# 戰術指揮官 ${unitName}道具`;
      else if (t.includes('무기 및 기술')) zh = `# ${unitName}武器與技術`;
    }
    outLines.push(zh);
  }

  const title = `戰術指揮官 ${unitName}道具`;
  const fmLines = fm.split('\n')
    .map((l) => (l.startsWith('title:') ? `title: "${title}"` : l.startsWith('category:') ? 'category: "戰術指揮官"' : l))
    .concat(['lang: zh-TW', 'translated_by: "lookup-table (DS)"']);

  let output = `---\n${fmLines.join('\n')}\n---\n${outLines.join('\n')}\n`;
  output = output.replace(/---\n\n\n#/, '---\n\n#');
  fs.writeFileSync(path.join(OUT, outName), output, 'utf8');
  console.log(`wrote ${outName}: ${rebuilt.length} tables`);
}
