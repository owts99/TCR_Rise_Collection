import fs from 'node:fs';
import path from 'node:path';

const src = fs.readFileSync('everzone/posts/146-택티컬-커맨더스-커맨더-레벨업-필요-경험치.md', 'utf8');
const fmEnd = src.indexOf('\n---', 4);
const fm = src.slice(4, fmEnd);
const body = src.slice(fmEnd + 4)
  .replace('# 택티컬 커맨더스 커맨더 레벨업 필요 경험치', '# 戰術指揮官 指揮官升級所需經驗值')
  .replace('# 택티컬 커맨더스 커맨더 레벨업 필요 경험치', '# 戰術指揮官 指揮官升級所需經驗值')
  .replace('각 커맨더 레벨에서 다음 레벨로 올라가기 위한 필요 경험치', '各指揮官等級升到下一級所需的經驗值')
  .replace(/\| 레벨 \| 필요경험치 \|/g, '| 等級 | 所需經驗值 |')
  .replace('- [(index) 택티컬 커맨더 유닛 스펙 링크]', '- [(index) 戰術指揮官單位規格連結]');

const fmLines = fm.split('\n').map((l) =>
  l.startsWith('title:') ? 'title: "戰術指揮官 指揮官升級所需經驗值"'
    : l.startsWith('category:') ? 'category: "戰術指揮官"' : l,
).concat(['lang: zh-TW', 'translated_by: "lookup-table (DS)"']);

const out = `---\n${fmLines.join('\n')}\n---\n${body}`;
fs.writeFileSync('everzone/posts-zh/146-戰術指揮官-指揮官升級所需經驗值.md', out, 'utf8');
console.log('wrote 146');
