import fs from 'node:fs';
import path from 'node:path';

const POSTS = path.resolve('everzone/posts');
const OUT = path.resolve('everzone/posts-zh');
const WORK = path.resolve('everzone/translate/_work_posts_zh');

const rawMap = JSON.parse(fs.readFileSync(path.join(WORK, 'name_map.json'), 'utf8'));
const corrections = {
  '머스크': '馬斯克引擎',
  '강화머스크': '強化馬斯克引擎',
  '아코픽센서': '聲學感測器',
  '화이트킷센서': '白套件感測器',
  '루빅센서': '魯比克感測器',
  '캠머스': '卡姆斯',
  '캠푸스': '坎普斯',
  '퀘이션트': '奎森特',
  '케이아스': '凱亞斯',
  '피젼셀': '鴿式電池',
  '블루라이브': '藍色驅動',
  '레드라이브': '紅色驅動',
  '리튜카듐전지': '鋰鎘電池',
  'P-쏠라셀': 'P-太陽能電池',
  '우크레인셀': '鈾電池',
  '메타포지': '元鍛爐',
  '스텀포지': '蒸氣鍛爐',
  '퍼지메탄리액터': '淨化甲烷反應爐',
  '애로운센서': '箭式感測器',
  '네로믹센서': '神經感測器',
  '택소그램': '塔克索格蘭',
  '헤비택소그램': '重型塔克索格蘭',
  '폴리택손': '波利塔克森',
  '폴리그론': '波利格隆',
  '스트링기어': '弦式齒輪',
  '해비밸브': '重型閥門',
  'XII-밸브': 'XII 閥門',
  '앤티뷸릿': '反子彈',
  '앤티뷸릿-Ⅱ': '反子彈-Ⅱ',
  '앤티뷸릿-Ⅲ': '反子彈-Ⅲ',
  '뷸릿킬드-Ⅱ': '子彈抗性-Ⅱ',
  '뷸릿킬드-Ⅲ': '子彈抗性-Ⅲ',
  '앤티스네이크': '反蛇行',
  '앤티스네이크-Ⅱ': '反蛇行-Ⅱ',
  '앤티스네이크-Ⅲ': '反蛇行-Ⅲ',
  '스네이크킬드': '蛇行抗性',
  '스네이크킬드-Ⅱ': '蛇行抗性-Ⅱ',
  '스네이크킬드-Ⅲ': '蛇行抗性-Ⅲ',
  '레이저킬드': '雷射抗性',
  '레이저킬드-Ⅱ': '雷射抗性-Ⅱ',
  '레이저킬드-Ⅲ': '雷射抗性-Ⅲ',
  '라이트틸라아머': '輕型提拉裝甲',
  '미디움틸라아머': '中型提拉裝甲',
  '하프틸라아머': '半身提拉裝甲',
  '헤비틸라아머': '重型提拉裝甲',
  '울트라틸라아머': '終極提拉裝甲',
  '하프베스트': '半身背心',
  '하프티타늄아머': '半身鈦裝甲',
  '미디움뉴트론셀': '中型中子電池',
  '헤비뉴트론셀': '重型中子電池',
  '라이트뉴트론셀': '輕型中子電池',
  '라이트뉴트론셀-X': '輕型中子電池-X',
  '로드헤더': '掘進機',
  '히스톨로그램': '組織圖',
  '리소닉플러그': '共鳴插頭',
};
const nameMap = { ...rawMap, ...corrections };

const headerMap = {
  '이름': '名稱',
  '테크레벨': '科技等級',
  '시야거리': '視野距離',
  '에너지소모량': '能量消耗',
  '에너지 소모량': '能量消耗',
  '타입': '類型',
  '출력': '輸出',
  '복잡도': '複雜度',
  '무게': '重量',
  '공간': '空間',
  '보너스체력': '額外體力',
  '최대복잡도': '最大複雜度',
  '보너스 경험치': '額外經驗值',
  '최대에너지': '最大能量',
  '에너지재생률': '能量再生率',
  '저항력': '抗性',
  '체력': '體力',
};

const valueMap = {
  '방향성': '方向性',
  '전방향': '全向',
  '재충전(O)': '可充電(O)',
  '비재충전(X)': '不可充電(X)',
  '총기': '槍械',
  '레이저': '雷射',
  '미사일': '飛彈',
  '총기,레이저': '槍械、雷射',
  '총기,미사일': '槍械、飛彈',
  '레이저,미사일': '雷射、飛彈',
};

const files = {
  102: '102-택티컬-커맨더스-인간-유닛-공통-아이템.md',
  103: '103-택티컬-커맨더스-차량-유닛-공통-아이템.md',
  104: '104-택티컬-커맨더스-비행-유닛-공통-아이템.md',
};
const titles = {
  102: '戰術指揮官 人類單位共通道具',
  103: '戰術指揮官 車輛單位共通道具',
  104: '戰術指揮官 飛行單位共通道具',
};

const hasHangul = (s) => /[\uAC00-\uD7A3]/.test(s);

function tableBlocks(lines) {
  const blocks = [];
  let cur = null;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith('|')) {
      if (!cur) {
        cur = { start: i, lines: [] };
        blocks.push(cur);
      }
      cur.lines.push(lines[i]);
    } else {
      cur = null;
    }
  }
  return blocks;
}

function splitCells(line) {
  return line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((s) => s.trim());
}

function displayName(src) {
  if (!hasHangul(src)) return src;
  const zh = nameMap[src];
  return zh ? `${zh}（${src}）` : src;
}

function rebuildTable(srcBlock) {
  const rows = srcBlock.lines;
  const header = splitCells(rows[0]).map((c) => headerMap[c] ?? c);
  const n = header.length;
  const out = [];
  out.push(`| ${header.join(' | ')} |`);
  out.push(`| ${Array(n).fill('---').join(' | ')} |`);
  for (const line of rows.slice(2)) {
    const cells = splitCells(line);
    if (cells.length !== n) throw new Error(`source column mismatch: ${line}`);
    cells[0] = displayName(cells[0]);
    for (let i = 1; i < cells.length; i++) {
      if (valueMap[cells[i]]) cells[i] = valueMap[cells[i]];
    }
    out.push(`| ${cells.join(' | ')} |`);
  }
  return out;
}

const proseFixes = [
  ['- 可充電（O）：裝填或更換時能量會補充', '- 可充電（O）：採集或採礦時能量會回復。'],
  ['- 可充電（O）：衝擊或彎曲時能量會恢復（即使能量耗盡也能逐步移動）', '- 可充電（O）：採集或採礦時能量會回復（即使沒有能量也能緩慢移動）。'],
  ['- 不可充電（X）：持續動力（能量耗盡則無法移動）', '- 不可充電（X）：電池式動力（沒有能量就無法移動）。'],
  ['- 不可充電（X）：電池式動力（能量不補充）', '- 不可充電（X）：電池式動力（能量不會回復）。'],
  ['- 戰車因能量消耗量較高，因此能量會快速消耗', '- 戰車的能量消耗較高，因此能量消耗得很快。'],
  ['類型是以能量可充電的項目（O）與不可充電的項目（X）區分', '類型分為能量可充電的道具（O）與不可充電的道具（X）。'],
  ['- 鈦裝甲與鎢裝甲是提供高額體力加成之高級裝甲', '- 鈦裝甲與提拉裝甲是提供高額體力加成的上級裝甲。'],
  ['- 人類單位裝甲是步兵單位所穿戴的防禦裝備', '- 人類單位裝甲是步兵單位穿戴的防禦裝備。'],
  ['- 裝甲可提升單位的體力，並提供對特定武器之抗性', '- 裝甲可提升單位體力，並提供對特定武器的抗性。'],
  ['- 除標準裝甲外，尚有特殊抗性裝甲，可在 Pluto 外星行星進行升級', '- 除標準裝甲外，還有特殊抗性裝甲，可在 Pluto 外星行星升級。'],
];

for (const [id, srcName] of Object.entries(files)) {
  const srcText = fs.readFileSync(path.join(POSTS, srcName), 'utf8');
  const outFile = fs.readdirSync(OUT).find((f) => f.startsWith(id + '-') && f.endsWith('.md'));
  const outText = fs.readFileSync(path.join(OUT, outFile), 'utf8');

  const srcBody = srcText.slice(srcText.indexOf('\n---', 4) + 4);
  const outFmEnd = outText.indexOf('\n---', 4) + 4;
  const fm = outText.slice(0, outFmEnd);
  const outBody = outText.slice(outFmEnd);

  const srcTables = tableBlocks(srcBody.split('\n'));
  const outTables = tableBlocks(outBody.split('\n'));
  if (srcTables.length !== outTables.length) {
    throw new Error(`${id}: table count ${srcTables.length} vs ${outTables.length}`);
  }

  const rebuilt = srcTables.map(rebuildTable);

  let ti = 0;
  const lines = outBody.split('\n');
  const outLines = [];
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith('|')) {
      if (ti < outTables.length && i === outTables[ti].start) {
        outLines.push(...rebuilt[ti]);
        ti++;
      }
      continue;
    }
    let line = lines[i];
    for (const [from, to] of proseFixes) line = line.split(from).join(to);
    outLines.push(line);
  }

  const newFm = fm
    .split('\n')
    .map((l) => (l.startsWith('title:') ? `title: "${titles[id]}"` : l))
    .join('\n');
  let body = outLines.join('\n');

  body = body.replace(/^# 戰術指揮官(人類|車輛|飛行)單位通用(道具|物品)$/m, (m, a, b) => `# 戰術指揮官 ${a}單位共通${b === '物品' ? '道具' : '道具'}`);
  body = body.replace(/# 人類單位 動力資訊/g, '# 人類單位動力資訊');

  fs.writeFileSync(path.join(OUT, outFile), newFm + body, 'utf8');
  console.log(`rebuilt ${outFile}: ${rebuilt.length} tables`);
}
