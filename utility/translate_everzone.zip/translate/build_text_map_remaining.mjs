import fs from 'node:fs';
import path from 'node:path';

const BASE = 'http://127.0.0.1:8090/v1';
const MODEL = 'qwen36-35b-a3b';
const WORK = path.resolve('everzone/translate/_work_posts_zh');

const lines = fs.readFileSync(path.join(WORK, 'remaining_prose.txt'), 'utf8')
  .split('\n').map((s) => s.trim()).filter(Boolean);
console.log(`prose lines: ${lines.length}`);

async function chat(prompt, maxTokens) {
  const body = {
    model: MODEL,
    messages: [
      { role: 'system', content: '你是韓→繁中遊戲文件翻譯，只輸出 TSV。' },
      { role: 'user', content: prompt },
    ],
    temperature: 0,
    top_p: 1,
    max_tokens: maxTokens,
    stream: false,
  };
  const res = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(900000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const j = await res.json();
  return j.choices?.[0]?.message?.content ?? '';
}

const promptFor = (chunk) => `你是專業韓→繁中（台灣）遊戲文件翻譯。把以下每一行翻成繁體中文。
只輸出「id<TAB>譯文」，一行一筆，id 與順序完全照抄，不要合併、不要說明、不要 code fence。

規則：
- 保留 Markdown 標記（#、-、**）、數字、單位、英文代號、0x 代碼。
- 表格列不會出現在這裡；這些是標題、說明、統計列與註解。
- 單位／道具名用台灣繁中；不確定的專有名詞用合理音譯。
- 不要加原文沒有的內容。

${chunk.map(([id, text]) => `${id}\t${text}`).join('\n')}`;

const map = {};
for (let i = 0; i < lines.length; i += 40) {
  const chunk = lines.slice(i, i + 40).map((text, j) => [`L${String(i + j + 1).padStart(3, '0')}`, text]);
  console.log(`batch ${i / 40 + 1}: ${chunk.length}`);
  let text = '';
  for (let attempt = 1; attempt <= 3; attempt++) {
    text = await chat(promptFor(chunk), 4500);
    const got = chunk.filter(([id]) => new RegExp(`^${id}\\t`, 'm').test(text));
    console.log(`  attempt ${attempt}: ${got.length}/${chunk.length}`);
    if (got.length === chunk.length) break;
  }
  for (const line of text.split('\n')) {
    const m = line.match(/^(L\d{3})\t(.+)$/);
    if (m) map[m[1]] = m[2].trim();
  }
}

const missing = lines.map((_, i) => `L${String(i + 1).padStart(3, '0')}`).filter((id) => !map[id]);
console.log(`mapped ${Object.keys(map).length}/${lines.length}, missing ${missing.length}`);
for (const id of missing.slice(0, 20)) console.log(`${id}\t${lines[Number(id.slice(1)) - 1]}`);

fs.writeFileSync(path.join(WORK, 'text_map_remaining.json'), JSON.stringify(map, null, 2), 'utf8');
fs.writeFileSync(path.join(WORK, 'text_map_remaining.tsv'), Object.entries(map).map(([k, v]) => `${k}\t${v}`).join('\n') + '\n', 'utf8');
