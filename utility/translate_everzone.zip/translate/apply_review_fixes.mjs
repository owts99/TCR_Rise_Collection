import fs from 'node:fs';
import path from 'node:path';

const OUT = path.resolve('everzone/posts-zh');
const fixes = [
  ['馬斯克引擎（머스크）', 'Musk 引擎（머스크）'],
  ['強化馬斯克引擎（강화머스크）', '強化 Musk 引擎（강화머스크）'],
  ['視覺護目感測器（비젼가글센서）', '視覺護目鏡感測器（비젼가글센서）'],
  ['四元電池（테라셀）', '太拉電池（테라셀）'],
  ['輕四元電池（라이트테라셀）', '輕型太拉電池（라이트테라셀）'],
  ['重四元電池（헤비테라셀）', '重型太拉電池（헤비테라셀）'],
  ['鴿式電池（피젼셀）', '分裂電池（피젼셀）'],
  ['新視電池（뉴트로피젼셀）', '中子分裂電池（뉴트로피젼셀）'],
  ['水彈裝甲板（수탄플레이트）', '蘇坦裝甲板（수탄플레이트）'],
  ['重型水彈（헤비스탄）', '重型蘇坦（헤비스탄）'],
  ['多色感測器（폴리크롬센서）', '多光譜感測器（폴리크롬센서）'],
  ['跨域引擎', '傳輸引擎'],
  ['子彈四元', '子彈四重'],
  ['光束四元', '光束四重'],
  ['蛇形四元', '蛇形四重'],
];

for (const file of fs.readdirSync(OUT).filter((f) => f.endsWith('.md'))) {
  const full = path.join(OUT, file);
  let text = fs.readFileSync(full, 'utf8');
  let count = 0;
  for (const [from, to] of fixes) {
    const parts = text.split(from);
    if (parts.length > 1) {
      count += parts.length - 1;
      text = parts.join(to);
    }
  }
  fs.writeFileSync(full, text, 'utf8');
  console.log(`${file}: ${count} replacements`);
}
