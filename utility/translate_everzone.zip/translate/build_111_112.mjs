import fs from 'node:fs';
import path from 'node:path';

const POSTS = path.resolve('everzone/posts');
const OUT = path.resolve('everzone/posts-zh');

const nameMap = {
  'UCD앰플': 'UCD 安瓿',
  'MCD앰플': 'MCD 安瓿',
  '클로킹디바이스': '隱形裝置',
  '레비테이트': '懸浮',
  'EMP건': 'EMP 槍',
  'EMP웨이브': 'EMP 波',
  'EMP리드건': 'EMP 鉛槍',
  '마이크로힐': '微型治療',
  '타이밍힐': '定時治療',

  '라이트발칸포': '輕型火神砲',
  'X-라이트발칸포': 'X-輕型火神砲',
  'G1-발칸포': 'G1 火神砲',
  'WO미사일': 'WO 飛彈',
  'V-머신건': 'V 機槍',
  'SDI-미사일': 'SDI 飛彈',
  'G2-발칸포': 'G2 火神砲',
  'V-피스트건': 'V 拳砲',
  '2LT미사일': '2LT 飛彈',
  'G3-발칸포': 'G3 火神砲',
  '6연발발칸포': '六連發火神砲',
  'G4-발칸포': 'G4 火神砲',
  '캐틀링발칸포': '加特林火神砲',
  'G5-발칸포': 'G5 火神砲',
  'SDI-II미사일': 'SDI-II 飛彈',
  '8연발발칸포': '八連發火神砲',
  '1LT미사일': '1LT 飛彈',
  'G7-발칸포': 'G7 火神砲',
  'CPT미사일': 'CPT 飛彈',
  '펄스건': '脈衝槍',
  'ASM': 'ASM',
  'LSM': 'LSM',
  'ASSA 미사일': 'ASSA 飛彈',
};

const headerMap = {
  '아이템이름': '道具名稱',
  '무기이름': '武器名稱',
  '발사체': '發射體',
  '테크레벨': '科技等級',
  '에너지소모량': '能量消耗',
  '설명': '說明',
  '공격력': '攻擊力',
  '사정거리': '射程',
  '연사속도': '連射速度',
  '공격모드': '攻擊模式',
  '무기타입': '武器類型',
  '에너지소비': '能量消耗',
  '복잡도/무게/공간': '複雜度/重量/空間',
  '지상 공격력': '地面攻擊力',
  '지상 사정거리': '地面射程',
  '지상 연사속도': '地面連射速度',
  '대공 공격력': '對空攻擊力',
  '대공 사정거리': '對空射程',
  '대공 연사속도': '對空連射速度',
};

const valueMap = {
  '지상전용': '僅對地',
  '지상/대공': '地/空',
  '대공전용': '僅對空',
  '대공': '對空',
  '일반미사일': '一般飛彈',
  '총기류': '槍械類',
  '레이저형': '雷射型',
  '좌우미사일': '左右飛彈',
  '인간 유닛 치료': '治療人類型單位',
  '기계 유닛 치료': '治療機械型單位',
  '인간형 유닛 치료': '治療人類型單位',
  '기계형 유닛 치료': '治療機械型單位',
  '유닛을 투명하게 만들어 적의 눈에 않보이게 한다': '使單位隱形，讓敵方看不見',
  '유닛을 부양 시켜 지뢰를 발지 않도록 해 준다 (추천-X)': '使單位懸浮，避免觸發地雷（不推薦）',
  '적의 에너지를 없애버린다 (무탱에게 효과적)': '清除敵方能量（對無坦特別有效）',
};

const textMap = {
  '- [(index) 택티컬 커맨더 유닛 스펙 링크](https://everzone.tistory.com/101)': '- [(index) 戰術指揮官單位規格連結](https://everzone.tistory.com/101)',
  '# 택티컬 커맨더스 트윈발칸 아이템': '# 戰術指揮官 雙管巴爾幹道具',
  '# 트윈발칸 무기 및 기술': '# 雙管巴爾幹武器與技術',
  '보병유닛들 중에서 가장 빠른 스피드를 자랑합니다. 레벨업도 빠릅니다. 단 장갑이 약한 편입니다.':
    '在步兵單位中擁有最快的速度，升級也快，但裝甲較弱。',
  '- 기본체력: 1600, 250(초기버전)': '- 基礎體力：1600，250（初期版本）',
  '- 기본공간: 80': '- 基礎空間：80',
  '- 기본무게: 80': '- 基礎重量：80',
  '## 특수아이템': '## 特殊道具',
  '## 무기 목록': '## 武器列表',
  '## 리플레이 자료로 확인된 값': '## 由重播資料確認的數值',

  '# 택티컬 커맨더스 엑소노이드 아이템': '# 戰術指揮官 艾克斯諾道具',
  '# 엑소노이드 무기 및 기술': '# 艾克斯諾武器與技術',
  '트윈발칸과 비슷한 다재다능한 유닛입니다. 속도도 빠르고 무기 장착 자유도가 있어서 여러가지로 쓸모 있습니다. 트윈발칸보다 레벨업은 느립니다.':
    '與 Twin Vulcan 類似的多用途單位。速度快，武器裝備自由度高，用途廣泛；升級速度比 Twin Vulcan 慢。',
  '- 기본체력: 2000, 250(초기버전)': '- 基礎體力：2000，250（初期版本）',
  '- 기본공간: 90': '- 基礎空間：90',
  '- 기본무게: 100': '- 基礎重量：100',
  '- **유일하게 지상/대공 공격력이 다른 데이터가 발견됨**': '- **唯一發現地面／對空攻擊力不同的資料**',
};

const files = [
  { id: 111, src: '111-택티컬-커맨더스-트윈발칸-아이템.md', out: '111-戰術指揮官-雙管巴爾幹道具.md', title: '戰術指揮官 雙管巴爾幹道具' },
  { id: 112, src: '112-택티컬-커맨더스-엑소노이드-아이템.md', out: '112-戰術指揮官-艾克斯諾道具.md', title: '戰術指揮官 艾克斯諾道具' },
];

const hasHangul = (s) => /[\uAC00-\uD7A3]/.test(s);
const splitCells = (line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((s) => s.trim());
const displayName = (src) => (hasHangul(src) && nameMap[src] ? `${nameMap[src]}（${src}）` : src);

function tableBlocks(lines) {
  const blocks = [];
  let cur = null;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith('|')) {
      if (!cur) { cur = { start: i, lines: [] }; blocks.push(cur); }
      cur.lines.push(lines[i]);
    } else cur = null;
  }
  return blocks;
}

function rebuildTable(block) {
  const rows = block.lines;
  const header = splitCells(rows[0]).map((c) => headerMap[c] ?? c);
  const n = header.length;
  const out = [`| ${header.join(' | ')} |`, `| ${Array(n).fill('---').join(' | ')} |`];
  for (const row of rows.slice(2)) {
    const cells = splitCells(row);
    if (cells.length !== n) throw new Error(`column mismatch: ${row}`);
    cells[0] = displayName(cells[0]);
    for (let i = 1; i < cells.length; i++) if (valueMap[cells[i]]) cells[i] = valueMap[cells[i]];
    out.push(`| ${cells.join(' | ')} |`);
  }
  return out;
}

for (const f of files) {
  const src = fs.readFileSync(path.join(POSTS, f.src), 'utf8').replace(/^\ufeff/, '');
  const fmEnd = src.indexOf('\n---', 4);
  const fm = src.slice(4, fmEnd);
  const body = src.slice(fmEnd + 4);
  const lines = body.split('\n');
  const blocks = tableBlocks(lines);
  const rebuilt = blocks.map(rebuildTable);

  const outLines = [];
  let bi = 0;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith('|')) {
      if (bi < blocks.length && i === blocks[bi].start) {
        outLines.push(...rebuilt[bi]);
        bi++;
      }
      continue;
    }
    const t = lines[i].trim();
    outLines.push(textMap[t] ?? lines[i]);
  }

  const fmLines = fm
    .split('\n')
    .map((l) => (l.startsWith('title:') ? `title: "${f.title}"` : l.startsWith('category:') ? 'category: "戰術指揮官"' : l))
    .concat(['lang: zh-TW', 'translated_by: "lookup-table (DS)"']);

  let output = `---\n${fmLines.join('\n')}\n---\n${outLines.join('\n')}\n`;
  output = output.replace(/---\n\n\n#/, '---\n\n#');
  fs.writeFileSync(path.join(OUT, f.out), output, 'utf8');
  console.log(`wrote ${f.out}: ${rebuilt.length} tables, ${blocks.reduce((n, b) => n + b.lines.length - 2, 0)} data rows`);
}
