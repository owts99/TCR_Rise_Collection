import fs from 'node:fs';

const BASE = 'http://127.0.0.1:8090/v1';
const MODEL = 'qwen36-35b-a3b';
const src = fs.readFileSync('everzone/posts/147-택티컬-커맨더스-몬스터-유닛-스펙.md', 'utf8');

const prompt = `你是專業韓→繁中（台灣）遊戲文件翻譯。把以下 Markdown 全文翻成繁體中文。

規則：
- 保留 frontmatter 結構；title 翻成中文，category 設為「戰術指揮官」。
- 保留所有 Markdown 表格：列數、欄數、數字、星號評級、0x 代碼、空欄都不可改變。
- 保留所有標題層級、清單、空行、水平線。
- 專有名詞用中文（英文原名可保留），同一名稱前後一致。
- 只輸出完整 Markdown，不要 code fence、不要說明。

原文：
${src}`;

const body = {
  model: MODEL,
  messages: [
    { role: 'system', content: '你是遊戲文件翻譯，只輸出 Markdown。' },
    { role: 'user', content: prompt },
  ],
  temperature: 0,
  top_p: 1,
  max_tokens: 16000,
  stream: false,
};
const res = await fetch(`${BASE}/chat/completions`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify(body),
  signal: AbortSignal.timeout(1200000),
});
if (!res.ok) throw new Error(`HTTP ${res.status}`);
const j = await res.json();
let out = j.choices?.[0]?.message?.content ?? '';
out = out.replace(/^\s*```(?:markdown|md)?\s*/i, '').replace(/\s*```\s*$/i, '').trim();
fs.writeFileSync('everzone/posts-zh/147-戰術指揮官-怪物單位規格.md', out + '\n', 'utf8');
console.log(`wrote 147: ${out.length} chars`);
console.log(out.split('\n').slice(0, 25).join('\n'));
