import fs from 'node:fs';

const q = 'everzone/posts-zh/110-戰術指揮官-哥利亞道具.md';
let t = fs.readFileSync(q, 'utf8');
t = t.replace(/電路火箭筒/g, '迴路火箭筒');
if (!t.includes('reviewed_by:')) {
  t = t.replace(
    'translated_by: "lookup-table (DS)"',
    'translated_by: "lookup-table (DS)"\nreviewed_by: "qwen36-35b-a3b"\nreview_confidence: 95\nreview_verdict: "needs_fix"\nds_review: "pass_after_minor_fixes"',
  );
}
fs.writeFileSync(q, t, 'utf8');
console.log('updated 110');
