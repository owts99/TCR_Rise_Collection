import fs from 'node:fs';
import path from 'node:path';

const BASE = 'http://127.0.0.1:8090/v1';
const MODEL = 'qwen36-35b-a3b';
const POSTS = path.resolve('everzone/posts');
const WORK = path.resolve('everzone/translate/_work_posts_zh');

const files = [
  '106-택티컬-커맨더스-바즈노이드-아이템.md',
  '107-택티컬-커맨더스-레일건너-아이템.md',
  '108-택티컬-커맨더스-GTA로켓런쳐-아이템.md',
  '109-택티컬-커맨더스-샤크-아이템.md',
];

const skip = new Set(['아이템이름', '무기이름', '발사체', '---']);
const names = [];
for (const f of files) {
  for (const line of fs.readFileSync(path.join(POSTS, f), 'utf8').split('\n')) {
    const m = line.match(/^\| ([^|]+) \|/);
    if (!m) continue;
    const n = m[1].trim();
    if (skip.has(n) || /^0x[0-9A-F]+$/i.test(n)) continue;
    if (!names.includes(n)) names.push(n);
  }
}
console.log(`unique names: ${names.length}`);

async function chat(prompt, maxTokens) {
  const body = {
    model: MODEL,
    messages: [
      { role: 'system', content: '你是遊戲在地化譯者，只輸出 TSV，不要說明。' },
      { role: 'user', content: prompt },
    ],
    temperature: 0,
    top_p: 1,
    max_tokens: maxTokens,
    stream: false,
  };
  const res = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(600000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${(await res.text()).slice(0, 300)}`);
  const j = await res.json();
  return j.choices?.[0]?.message?.content ?? '';
}

const promptFor = (chunk) => `你是遊戲在地化譯者。把以下韓國遊戲《Tactical Commanders》的單位道具與武器名稱翻成台灣繁體中文。
只輸出「韓文原名<TAB>中文譯名」，一行一筆，不要編號、不要說明、不要 code fence。

規則：
- 名稱要像遊戲道具/武器名，2–10 個字為主，不要保留韓文。
- 同一系列用相同前綴，例如 폴라리스 → 北極星、로켓런쳐 → 火箭筒、머신건 → 機槍、라이플 → 步槍、레이저 → 雷射。
- 後綴：건=槍、런쳐=火箭筒、미사일=飛彈、라이플=步槍、머신건=機槍、앰플=安瓿、디바이스=裝置。
- 不要加括號、不要加英文，但 MK-、GT、GX、ATA、ACS、AGA、ASA、ICBM 等原廠代號保留。
- 例：롱레인지스틸건=長程鋼鐵槍、폴라리스=北極星、헤비머신건=重型機槍。

名稱：
${chunk.join('\n')}`;

const map = {};
for (let i = 0; i < names.length; i += 50) {
  const chunk = names.slice(i, i + 50);
  console.log(`batch ${i / 50 + 1}: ${chunk.length}`);
  let text = '';
  for (let attempt = 1; attempt <= 3; attempt++) {
    text = await chat(promptFor(chunk), 3000);
    const got = chunk.filter((n) => text.includes(n + '\t'));
    console.log(`  attempt ${attempt}: ${got.length}/${chunk.length}`);
    if (got.length === chunk.length) break;
  }
  for (const line of text.split('\n')) {
    const m = line.match(/^([^\t]+)\t(.+)$/);
    if (!m) continue;
    const ko = m[1].trim();
    const zh = m[2].trim();
    if (names.includes(ko) && !map[ko]) map[ko] = zh;
  }
}

const missing = names.filter((n) => !map[n]);
console.log(`mapped: ${Object.keys(map).length}/${names.length}, missing: ${missing.length}`);
if (missing.length) console.log('MISSING:\n' + missing.join('\n'));

fs.writeFileSync(path.join(WORK, 'name_map_106_109.json'), JSON.stringify(map, null, 2), 'utf8');
fs.writeFileSync(path.join(WORK, 'name_map_106_109.tsv'), names.map((n) => `${n}\t${map[n] ?? ''}`).join('\n') + '\n', 'utf8');
console.log('wrote name_map_106_109.json / .tsv');
