# 翻譯資料包（韓 → 繁中）

## 已完成：本機 LLM 自動翻譯

用 [translate-local.mjs](../../translate-local.mjs) 直接驅動本機 OpenAI 相容端點（`http://127.0.0.1:8090/v1`）跑完：

| 項目 | 結果 |
| --- | --- |
| 片語 | 1,559 / 1,559 全數譯完，0 空白 |
| 由人工術語表直接覆蓋 | 309 條（表頭、單位名、屬性名，100% 可控） |
| Spark-X2.5-4B 翻譯 | 1,153 條（63 批 × 25 條，約 8 分鐘） |
| qwen36-35b-a3b 重譯 | 129 條（97 條可疑行 + 32 條逗號清單格，約 2 分鐘） |
| 人工修正 | 4 條（`overrides.csv`） |
| 殘留問題 | 片假名 0 條、數字遺失 0 條（2 條為 «2→兩» 的正常轉換） |

輸出檔：[`phrases.zh.csv`](phrases.zh.csv)（`zh_tw` 已填）、[`glossary-all.csv`](glossary-all.csv)（322 條術語，可重用）、[`merge-report.json`](merge-report.json)（QC 報告）。

### 重跑方式

```powershell
node translate-local.mjs terms 25        # 補術語（可續跑）
node translate-local.mjs phrases 25      # 片語（可續跑，已完成的會跳過）
node translate-local.mjs suspects        # 列出可疑行
node translate-local.mjs retry 10        # 用指定模型重譯可疑行
node translate-local.mjs merge           # 合併 + QC + 產生 phrases.zh.csv
```

換模型：`$env:LOCAL_LLM_MODEL="qwen36-35b-a3b"`。若要整份改用 qwen 重跑，先改名 `phrases.auto.jsonl` → `phrases.spark.jsonl` 再執行 `phrases`。
人工覆蓋：把 `id,zh_tw` 寫進 [`overrides.csv`](overrides.csv)，再跑 `merge`。

### 品質實測（4B vs 35B）

| 原文 | Spark-X2.5-4B | qwen36-35b-a3b |
| --- | --- | --- |
| 제품을 거꾸로 들고 급수부에 물을… | 即進行注水。（截斷） | 將產品倒置，向供水部注水並啟動直到發出巨大聲響即可。 |
| 1렙(전략1?)에 해당하는 체력 추가 계산… | 由 replay 資料確認的數值（抓到別條） | 推測已納入等級 1（戰略 1？）的額外體力計算 |
| 아르코리액터 | アーコリエクター（變成日文） | 아르코리액터（保留原文） |

4B 的譯文可讀、夠用，但會有：名稱漂移（`택컴` 曾被譯成「戰團」）、偶發語意簡化、極少數整條抓錯。要出版級品質建議整份用 35B 再跑一次（估 15–20 分鐘）。

---

來源：[everzone.tistory.com](https://everzone.tistory.com/101) 全站 54 篇（택티컬 커맨더스 / Tactical Commanders 遊戲 wiki）。
由 [extract-phrases.mjs](../../extract-phrases.mjs) 從 `../posts/*.md` 抽出。

| 檔案 | 內容 |
| --- | --- |
| `phrases.csv` | 1,559 條不重複片語（句子 / 表格儲存格 / 標題 / 清單項），共 4,101 次出現 |
| `terms.csv` | 280 條高頻短詞（表格標頭與欄位值為主），當術語表用 |
| `stats.json` | 抽取統計 |

## phrases.csv 欄位

| 欄位 | 說明 |
| --- | --- |
| `id` | `P0001`…穩定識別碼，翻完用它對回 |
| `batch` | 每 50 條一批（1–32），方便切給 context 有限的本地模型 |
| `kind` | `sentence` / `table_cell` / `heading` / `list_item` |
| `ko` | 韓文原文（已去 Markdown 標記、連結只留文字） |
| `chars` | 字元數（含空白） |
| `occurrences` | 全站出現次數（去重前） |
| `post_ids` | 出現在哪些文章 id（最多列 8 個） |
| `source` | 首次出現位置 `檔名:行號` |
| `zh_tw` | 空白欄，填譯文 |

## terms.csv 欄位

`id, ko, chars, occurrences, post_ids, zh_tw` — 只收出現 ≥2 次、長度 ≤24、非句子的片段，等於自動抓出來的術語表（例：`지상/대공` 出現 335 次、`테크레벨` 96 次）。

## 為什麼先去重

原文 4,101 個片段去重後只剩 1,559 條，等於**省掉 62% 的翻譯量**；翻譯時把 `zh_tw` 填回去、再依 `occurrences` 套用到所有出現位置即可。

## 建議流程

1. 先翻 `terms.csv`（280 條，量小），建立固定譯名（單位名、武器名、屬性名）。
2. 把 `terms.csv` 的 `id,ko,zh_tw` 當術語表塞進 system prompt。
3. 按 `batch` 逐批翻 `phrases.csv`，只要求模型輸出 `id,zh_tw` 兩欄。
4. 用 `id` 合併回 `phrases.csv`，檢查有沒有漏行或行數不符。
5. （可選）我再幫你把 `zh_tw` 套回 Markdown，產出中文版站台。

## 注意

- 表格儲存格很多只是數字或符號，已被過濾；剩下的都含韓文。
- 專有名詞（휴머노이드 = Humanoid、레비테이트 = Levitate 等）建議保留原文或中英並列，方便對照遊戲內名稱。
- 原文有錯字與 2018 年前的舊資料，翻譯時照譯、不要自行修正數值。
