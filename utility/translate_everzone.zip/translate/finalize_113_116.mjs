import fs from 'node:fs';
import path from 'node:path';

const dir = path.resolve('everzone/posts-zh');

const edits = {
  '113-戰術指揮官-鈦拉諾道具.md': [
    ['| 隱形（클로킹） | - | - | 隱形 |', '| 隱形（클로킹） | - | - | 進入隱形狀態 |'],
  ],
  '116-戰術指揮官-魅影道具.md': [
    ['之後會追加「Phantom 視野內的偽裝、隱形會顯示 n 秒」的功能', '之後會追加「魅影視野內的偽裝、隱形會顯示 n 秒」的功能'],
  ],
};

const add = [
  'reviewed_by: "qwen36-35b-a3b"',
  'review_confidence: 95',
  'review_verdict: "needs_fix"',
  'ds_review: "pass_after_minor_fixes"',
].join('\n');

for (const f of fs.readdirSync(dir).filter((x) => /^11[3-6]-/.test(x))) {
  const q = path.join(dir, f);
  let t = fs.readFileSync(q, 'utf8');
  for (const [from, to] of edits[f] ?? []) t = t.split(from).join(to);
  if (!t.includes('reviewed_by:')) {
    t = t.replace('translated_by: "lookup-table (DS)"', `translated_by: "lookup-table (DS)"\n${add}`);
  }
  fs.writeFileSync(q, t, 'utf8');
  console.log(f);
}
