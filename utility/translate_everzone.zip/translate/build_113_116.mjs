import fs from 'node:fs';
import path from 'node:path';

const POSTS = path.resolve('everzone/posts');
const OUT = path.resolve('everzone/posts-zh');
const WORK = path.resolve('everzone/translate/_work_posts_zh');

const baseMap = JSON.parse(fs.readFileSync(path.join(WORK, 'name_map_106_109.json'), 'utf8'));
const nameMap = {
  ...baseMap,
  '레비테이트': '懸浮',
  'UCD앰플': 'UCD 安瓿',
  'MCD앰플': 'MCD 安瓿',
  '클로킹디바이스': '隱形裝置',
  '클로킹': '隱形',
  '플라스티마': '電漿體槍',

  // 113 Tilanoid
  '매캐넌부스터': '機械加農推進器',
  '유탄발사기': '榴彈發射器',
  '헤비기어머신건': '重型齒輪機槍',
  '뉴클건': '核子槍',
  '에드머신건': '艾德機槍',
  'TA유탄발사기': 'TA 榴彈發射器',
  '핸드캐논': '手砲',
  '에토머신건': '艾托機槍',
  '스타이어': '星輪',
  '배쉬핸드캐논': '重擊手砲',
  '헤비스타이어': '重型星輪',
  '배쉬라이플': '重擊步槍',
  '울트라스타이어': '終極星輪',
  '루비스타이어': '紅寶星輪',
  '스타라이플': '星際步槍',
  '수퍼머신건': '超級機槍',

  // 114 Giant
  '헤비클로킹': '重型隱形',
  '케모플라쥐': '偽裝潛伏',
  '어스퀘이크': '地震',
  '스피드부스터': '速度推進器',
  '퀘이크화이어': '地震火焰',
  '플레임퀘이크': '火焰地震',
  '크레인너클': '起重機指虎',
  '리드너클': '鉛指虎',
  '아이언너클': '鋼鐵指虎',
  '티타늄피스트': '鈦拳',
  '드래곤피스트': '龍拳',
  '너클케인': '指虎杖',
  '피스트블레이드': '拳刃',
  '콘돌피스트': '神鷹拳',
  '블레이드': '刀刃',
  '너클블레이드': '指虎刃',
  '더블스파이너': '雙旋刃',
  '헤비머신너클': '重型機槍指虎',

  // 115 Blader
  '플라쉬세이버': '閃光軍刀',
  '쿼크소드': '夸克劍',
  '스파클세이버': '火花軍刀',
  '뉴트론소드': '中子劍',
  '레이세이버': '雷射軍刀',
  '글리머세이버': '微光軍刀',
  '글리머소드': '微光劍',
  '글로우세이버': '發光軍刀',
  '일렉트릭소드': '電擊劍',
  '세이버미라쥬': '軍刀幻影',
  '레드소드': '紅色劍',
  '스파클소드': '火花劍',
  '퀀텀미라쥬': '量子幻影',

  // 116 Phantom
  '스타쉘': '星殼',
  '팅클스타쉘': '叮噹星殼',
  '루나쉘': '月神殼',
  '커밋쉘': '彗星殼',
};

const headerMap = {
  '아이템이름': '道具名稱',
  '무기이름': '武器名稱',
  '발사체': '發射體',
  '테크레벨': '科技等級',
  '에너지소모량': '能量消耗',
  '설명': '說明',
  '공격력': '攻擊力',
  '사정거리': '射程',
  '연사속도': '連射速度',
  '공격모드': '攻擊模式',
  '무기타입': '武器類型',
  '에너지소비': '能量消耗',
  '복잡도/무게/공간': '複雜度/重量/空間',
};

const valueMap = {
  '지상전용': '僅對地',
  '지상/대공': '地/空',
  '대공전용': '僅對空',
  '대공': '對空',
  '일반미사일': '一般飛彈',
  '총기류': '槍械類',
  '레이저형': '雷射型',
  '좌우미사일': '左右飛彈',
  '근접공격': '近戰攻擊',
  '인간형 유닛 치료': '治療人類型單位',
  '기계형 유닛 치료': '治療機械型單位',
  '인간 유닛 치료': '治療人類型單位',
  '기계 유닛 치료': '治療機械型單位',
  '발자국을 남기지 않음': '不留腳印',
  '투명해짐': '隱形',
  '투명해진다': '隱形',
  '이동속도를 빠르게 해줌': '提升移動速度',
  '유닛의 속도를 빠르게 해줌': '提升單位速度',
  '잠복(적이 찾지도 못하며, 공격도 불가능하나, 자기 자신도 공격을 못한다)': '潛伏（敵方無法發現、無法攻擊，自身也無法攻擊）',
  '지진파 [주위에 있는 지상유닛에게 데미지를 입힘]': '地震波（對周圍地面單位造成傷害）',
  '조명탄': '照明彈',
};

const textMap = {
  '- [(index) 택티컬 커맨더 유닛 스펙 링크](https://everzone.tistory.com/101)': '- [(index) 戰術指揮官單位規格連結](https://everzone.tistory.com/101)',
  '## 특수아이템': '## 特殊道具',
  '## 무기 목록': '## 武器列表',
  '## 리플레이 자료로 확인된 값': '## 由重播資料確認的數值',

  '# 택티컬 커맨더스 틸라노이드 아이템': '# 戰術指揮官 鈦拉諾道具',
  '# 틸라노이드 무기 및 기술': '# 鈦拉諾武器與技術',
  '중장갑 지상 유닛입니다. 장갑이 뛰어난 대신 속도가 느린 편이며 사용무기는 유탄 발사기 같은 중무기를 사용하고, 사정거리도 매우 뛰어납니다. 단, 레벨업이 어렵습니다.':
    '重裝甲地面單位。裝甲優秀但速度較慢，使用榴彈發射器這類重武器，射程也非常出色；缺點是升級困難。',
  '- 기본체력: 2000, 350(초기버전)': '- 基礎體力：2000，350（初期版本）',
  '- 기본공간: 90': '- 基礎空間：90',
  '- 기본무게: 110': '- 基礎重量：110',

  '# 택티컬 커맨더스 자이안트 아이템': '# 戰術指揮官 巨人道具',
  '# 자이안트 무기 및 기술': '# 巨人武器與技術',
  '엄청난 힘과 파괴력을 자랑하는 지상유닛의 강자입니다. 단점이라면 적의 유닛에 직접 다가가서 공격해야만 한다는 점입니다. 1:1로 싸워서는 당할 자가 없는 육상의 최강 탱크입니다.':
    '擁有驚人力量與破壞力的地面單位霸主。缺點是必須貼近敵方單位才能攻擊。1 對 1 幾乎無敵的陸上最強戰車。',
  '- 기본체력: 2000, 500(초기버전)': '- 基礎體力：2000，500（初期版本）',
  '- 기본공간: 150': '- 基礎空間：150',
  '- 기본무게: 150': '- 基礎重量：150',

  '# 택티컬 커맨더스 블레이더 아이템': '# 戰術指揮官 刀鋒者道具',
  '# 블레이더 무기 및 기술': '# 刀鋒者武器與技術',
  '자이언트에 비해 장갑이 약하지만 매우 빠르며 클로킹을 장착할 수 있고 검을 사용하는 유닛입니다.':
    '相較 Giant 裝甲較弱，但速度極快，可裝備隱形，並使用劍的單位。',
  '- 기본체력: 1600, 600(초기버전)': '- 基礎體力：1600，600（初期版本）',
  '- 기본공간: 90': '- 基礎空間：90',
  '- 기본무게: 90': '- 基礎重量：90',

  '# 택티컬 커맨더스 팬텀 아이템': '# 戰術指揮官 魅影道具',
  '# 팬텀 무기 및 기술': '# 魅影武器與技術',
  '스피드도 어느 정도 있고 기본적인 공격력을 갖고 있는 유닛이며 조명탄을 사용할 수 있어 아군의 시야를 넓힐 수 있습니다.':
    '速度不錯，具備基本攻擊力，還能使用照明彈擴大友軍視野。',
  '- 기본체력: 1050, 500(초기버전)': '- 基礎體力：1050，500（初期版本）',
  '- 기본공간: 70': '- 基礎空間：70',
  '- 기본무게: 70': '- 基礎重量：70',
  '- 레일건너 무기와 같음': '- 與 Railgunner 武器相同',
  '조명탄:': '照明彈：',
  '- 검은색 부분을 비쳐준다.': '- 可照亮黑色區域。',
  '- 추후에는 팬텀 시아에 있는 캐모, 클락이 n초 보이는 기능이 추가됨 (계도나후검님 제보)':
    '- 之後會追加「Phantom 視野內的偽裝、隱形會顯示 n 秒」的功能（계도나후검 提供）',
};

const files = [
  { id: 113, src: '113-택티컬-커맨더스-틸라노이드-아이템.md', out: '113-戰術指揮官-鈦拉諾道具.md', title: '戰術指揮官 鈦拉諾道具' },
  { id: 114, src: '114-택티컬-커맨더스-자이안트-아이템.md', out: '114-戰術指揮官-巨人道具.md', title: '戰術指揮官 巨人道具' },
  { id: 115, src: '115-택티컬-커맨더스-블레이더-아이템.md', out: '115-戰術指揮官-刀鋒者道具.md', title: '戰術指揮官 刀鋒者道具' },
  { id: 116, src: '116-택티컬-커맨더스-팬텀-아이템.md', out: '116-戰術指揮官-魅影道具.md', title: '戰術指揮官 魅影道具' },
];

const hasHangul = (s) => /[\uAC00-\uD7A3]/.test(s);
const splitCells = (line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((s) => s.trim());
const displayName = (src) => (hasHangul(src) && nameMap[src] ? `${nameMap[src]}（${src}）` : src);

function tableBlocks(lines) {
  const blocks = [];
  let cur = null;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith('|')) {
      if (!cur) { cur = { start: i, lines: [] }; blocks.push(cur); }
      cur.lines.push(lines[i]);
    } else cur = null;
  }
  return blocks;
}

function rebuildTable(block) {
  const rows = block.lines;
  const header = splitCells(rows[0]).map((c) => headerMap[c] ?? c);
  const n = header.length;
  const out = [`| ${header.join(' | ')} |`, `| ${Array(n).fill('---').join(' | ')} |`];
  for (const row of rows.slice(2)) {
    const cells = splitCells(row);
    if (cells.length !== n) throw new Error(`column mismatch: ${row}`);
    cells[0] = displayName(cells[0]);
    for (let i = 1; i < cells.length; i++) if (valueMap[cells[i]]) cells[i] = valueMap[cells[i]];
    out.push(`| ${cells.join(' | ')} |`);
  }
  return out;
}

for (const f of files) {
  const src = fs.readFileSync(path.join(POSTS, f.src), 'utf8').replace(/^\ufeff/, '');
  const fmEnd = src.indexOf('\n---', 4);
  const fm = src.slice(4, fmEnd);
  const body = src.slice(fmEnd + 4);
  const lines = body.split('\n');
  const blocks = tableBlocks(lines);
  const rebuilt = blocks.map(rebuildTable);

  const outLines = [];
  let bi = 0;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith('|')) {
      if (bi < blocks.length && i === blocks[bi].start) {
        outLines.push(...rebuilt[bi]);
        bi++;
      }
      continue;
    }
    const t = lines[i].trim();
    outLines.push(textMap[t] ?? lines[i]);
  }

  const fmLines = fm
    .split('\n')
    .map((l) => (l.startsWith('title:') ? `title: "${f.title}"` : l.startsWith('category:') ? 'category: "戰術指揮官"' : l))
    .concat(['lang: zh-TW', 'translated_by: "lookup-table (DS)"']);

  let output = `---\n${fmLines.join('\n')}\n---\n${outLines.join('\n')}\n`;
  output = output.replace(/---\n\n\n#/, '---\n\n#');
  fs.writeFileSync(path.join(OUT, f.out), output, 'utf8');
  console.log(`wrote ${f.out}: ${rebuilt.length} tables, ${blocks.reduce((n, b) => n + b.lines.length - 2, 0)} data rows`);
}
