import fs from 'node:fs';
import path from 'node:path';

const POSTS = path.resolve('everzone/posts');
const OUT = path.resolve('everzone/posts-zh');
const WORK = path.resolve('everzone/translate/_work_posts_zh');

const rawMap = JSON.parse(fs.readFileSync(path.join(WORK, 'name_map_106_109.json'), 'utf8'));
const corrections = {
  '레비테이트': '懸浮',
  '파어웨이건': '遠距槍',
  '리드빔건': '引導光束槍',
  '레이저유크릭건': '雷射衝擊槍',
  '레이저엑트렉터': '雷射抽取器',
  '플라스티마': '電漿體槍',
  'X-GT로켓런쳐': 'X-GT 火箭筒',
  '프랙로켓런쳐': '破片火箭筒',
  '히트로켓런쳐': '熱能火箭筒',
  '엑스터': '艾克斯特',
  '트윈스니퍼': '雙聯狙擊槍',
  '로드레이저': '軌道雷射',
  '발리스타': '弩砲',
  '울트레일': '終極軌道',
  '블러드레일': '血軌',
  '카펫플로팅': '地毯浮游',
  'UCD앰플': 'UCD 安瓿',
  'MCD앰플': 'MCD 安瓿',
  'UCD 앰플': 'UCD 安瓿',
  'MCD 앰플': 'MCD 安瓿',
  'MK-Ⅰ어썰트건': 'MK-Ⅰ 突擊槍',
  'MK-Ⅱ어썰트건': 'MK-Ⅱ 突擊槍',
  'MK-Ⅲ어썰트건': 'MK-Ⅲ 突擊槍',
  'MK-Ⅳ어썰트건': 'MK-Ⅳ 突擊槍',
  'MK-Ⅴ어썰트건': 'MK-Ⅴ 突擊槍',
  'MK-Ⅵ어썰트건': 'MK-Ⅵ 突擊槍',
  '폴라리스ll': '北極星 II',
  '폴라리스lll': '北極星 III',
  '폴라리스lV': '北極星 IV',
  '폴라리스V': '北極星 V',
  'GT로켓런쳐': 'GT 火箭筒',
  'GX로켓런쳐': 'GX 火箭筒',
  'ATA로켓런쳐': 'ATA 火箭筒',
  'ACS로켓런쳐': 'ACS 火箭筒',
  'AGA로켓런쳐': 'AGA 火箭筒',
  'ASA로켓런쳐': 'ASA 火箭筒',
  'GM로켓런쳐': 'GM 火箭筒',
  '두키로켓런쳐': '杜基火箭筒',
  'SCA라이플': 'SCA 步槍',
  'ACV라이플': 'ACV 步槍',
  '인슬레이브-Ⅰ': '奴役-I',
  '인슬레이브-Ⅱ': '奴役-II',
  '클로킹디바이스': '隱形裝置',
  '레비테이트': '懸浮',
};
const nameMap = { ...rawMap, ...corrections };

const headerMap = {
  '아이템이름': '道具名稱',
  '무기이름': '武器名稱',
  '발사체': '發射體',
  '테크레벨': '科技等級',
  '에너지소모량': '能量消耗',
  '설명': '說明',
  '공격력': '攻擊力',
  '사정거리': '射程',
  '연사속도': '連射速度',
  '공격모드': '攻擊模式',
  '무기타입': '武器類型',
  '에너지소비': '能量消耗',
  '복잡도/무게/공간': '複雜度/重量/空間',
};

const valueMap = {
  '지상전용': '僅對地',
  '지상/대공': '地/空',
  '대공전용': '僅對空',
  '대공': '對空',
  '일반미사일': '一般飛彈',
  '총기류': '槍械類',
  '레이저형': '雷射型',
  '좌우미사일': '左右飛彈',
  '인간형 유닛 치료': '治療人類型單位',
  '기계형 유닛 치료': '治療機械型單位',
  '투명해짐': '隱形',
  '발자국을 남기지 않음': '不留腳印',
  '적의 유닛을 제어 불가능하게 만들어 버림': '使敵方單位失去控制',
};

const textMap = {
  '- [(index) 택티컬 커맨더 유닛 스펙 링크](https://everzone.tistory.com/101)': '- [(index) 戰術指揮官單位規格連結](https://everzone.tistory.com/101)',
  '# 택티컬 커맨더스 골리앗 아이템': '# 戰術指揮官 哥利亞道具',
  '# 골리앗 무기 및 기술': '# 哥利亞武器與技術',
  'GTA로켓런쳐에게 I.C.B.M(핵)이 있다면 이 유닛은 강한 장갑을 갖고 있고 후에 록 다운 아이템을 사용할 수 있습니다.':
    '如果 GTA 火箭筒擁有 I.C.B.M（核彈），這個單位則擁有強韌裝甲，之後還可以使用「鎖定」道具。',
  '- 기본체력: 1600, 600(초기버전)': '- 基礎體力：1600，600（初期版本）',
  '- 기본공간: 100': '- 基礎空間：100',
  '- 기본무게: 100': '- 基礎重量：100',
  '## 특수아이템': '## 特殊道具',
  '## 무기 목록': '## 武器列表',
  '## 리플레이 자료로 확인된 값': '## 由重播資料確認的數值',
};

const hasHangul = (s) => /[\uAC00-\uD7A3]/.test(s);
const splitCells = (line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((s) => s.trim());
const displayName = (src) => (hasHangul(src) && nameMap[src] ? `${nameMap[src]}（${src}）` : src);

function tableBlocks(lines) {
  const blocks = [];
  let cur = null;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith('|')) {
      if (!cur) { cur = { start: i, lines: [] }; blocks.push(cur); }
      cur.lines.push(lines[i]);
    } else cur = null;
  }
  return blocks;
}

function rebuildTable(block) {
  const rows = block.lines;
  const header = splitCells(rows[0]).map((c) => headerMap[c] ?? c);
  const n = header.length;
  const out = [`| ${header.join(' | ')} |`, `| ${Array(n).fill('---').join(' | ')} |`];
  for (const row of rows.slice(2)) {
    const cells = splitCells(row);
    if (cells.length !== n) throw new Error(`column mismatch: ${row}`);
    cells[0] = displayName(cells[0]);
    for (let i = 1; i < cells.length; i++) if (valueMap[cells[i]]) cells[i] = valueMap[cells[i]];
    out.push(`| ${cells.join(' | ')} |`);
  }
  return out;
}

const srcName = '110-택티컬-커맨더스-골리앗-아이템.md';
const outName = '110-戰術指揮官-哥利亞道具.md';
const title = '戰術指揮官 哥利亞道具';

const src = fs.readFileSync(path.join(POSTS, srcName), 'utf8').replace(/^\ufeff/, '');
const fmEnd = src.indexOf('\n---', 4);
const fm = src.slice(4, fmEnd);
const body = src.slice(fmEnd + 4);
const lines = body.split('\n');
const blocks = tableBlocks(lines);
const rebuilt = blocks.map(rebuildTable);

const outLines = [];
let bi = 0;
for (let i = 0; i < lines.length; i++) {
  if (lines[i].trim().startsWith('|')) {
    if (bi < blocks.length && i === blocks[bi].start) {
      outLines.push(...rebuilt[bi]);
      bi++;
    }
    continue;
  }
  const t = lines[i].trim();
  outLines.push(textMap[t] ?? lines[i]);
}

const fmLines = fm
  .split('\n')
  .map((l) => (l.startsWith('title:') ? `title: "${title}"` : l.startsWith('category:') ? 'category: "戰術指揮官"' : l))
  .concat(['lang: zh-TW', 'translated_by: "lookup-table (DS)"']);

fs.writeFileSync(path.join(OUT, outName), `---\n${fmLines.join('\n')}\n---\n${outLines.join('\n')}\n`, 'utf8');
console.log(`wrote ${outName}: ${rebuilt.length} tables, ${blocks.reduce((n, b) => n + b.lines.length - 2, 0)} data rows`);
