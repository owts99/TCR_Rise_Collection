import fs from 'node:fs';

const BASE = 'http://127.0.0.1:8090/v1';
const MODEL = 'qwen36-35b-a3b';
const src = fs.readFileSync('everzone/posts/101-택티컬-커맨더스-유닛-스펙.md', 'utf8');

const prompt = `你是專業韓→繁中（台灣）遊戲文件翻譯。把以下 Markdown 全文翻成繁體中文。

規則：
- 保留 frontmatter 結構；title 翻成中文，category 設為「戰術指揮官」。
- 保留所有 Markdown 表格：列數、欄數、數字、單位、括號註記都不可改變。
- 表格內的單位名稱用既有譯名：Humanoid（戰猿）、Bazonoid（巴茲尼德）、Railgunner（軌道砲手）、GTA Rocket Launcher（GTA 火箭筒）、Shark（鯊魚）、Goliath（哥利亞）、Twin Vulcan（雙管巴爾幹）、Exonoid（艾克斯諾）、Tilanoid（鈦拉諾）、Giant（巨人）、Blader（刀鋒者）、Phantom（魅影）、Sniper（狙擊手）；車輛與飛行單位沿用既有中文名。
- 保留連結 URL，只翻連結文字。
- 只輸出完整 Markdown，不要 code fence、不要說明。

原文：
${src}`;

const body = {
  model: MODEL,
  messages: [
    { role: 'system', content: '你是遊戲文件翻譯，只輸出 Markdown。' },
    { role: 'user', content: prompt },
  ],
  temperature: 0,
  top_p: 1,
  max_tokens: 20000,
  stream: false,
};
const res = await fetch(`${BASE}/chat/completions`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify(body),
  signal: AbortSignal.timeout(1200000),
});
if (!res.ok) throw new Error(`HTTP ${res.status}`);
const j = await res.json();
let out = j.choices?.[0]?.message?.content ?? '';
out = out.replace(/^\s*```(?:markdown|md)?\s*/i, '').replace(/\s*```\s*$/i, '').trim();
fs.writeFileSync('everzone/posts-zh/101-戰術指揮官-單位規格.md', out + '\n', 'utf8');
console.log(`wrote 101: ${out.length} chars`);
console.log(out.split('\n').slice(0, 30).join('\n'));
