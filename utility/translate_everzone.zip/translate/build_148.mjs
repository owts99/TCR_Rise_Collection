import fs from 'node:fs';
import path from 'node:path';

const BASE = 'http://127.0.0.1:8090/v1';
const MODEL = 'qwen36-35b-a3b';
const src = fs.readFileSync('everzone/posts/148-택티컬-커맨더스-미구현-컨텐츠-발견---아이템-거래.md', 'utf8');

const prompt = `你是專業韓→繁中（台灣）遊戲文件翻譯。把以下 Markdown 全文翻成繁體中文。

規則：
- 保留 frontmatter 結構；title 翻成中文，category 翻成「戰術指揮官」。
- 保留所有 Markdown 標記、圖片 URL、連結 URL、空行。
- 不要改動 URL、檔名、數字。
- 只輸出完整 Markdown，不要 code fence、不要說明。

原文：
${src}`;

const body = {
  model: MODEL,
  messages: [
    { role: 'system', content: '你是遊戲文件翻譯，只輸出 Markdown。' },
    { role: 'user', content: prompt },
  ],
  temperature: 0,
  top_p: 1,
  max_tokens: 5000,
  stream: false,
};
const res = await fetch(`${BASE}/chat/completions`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify(body),
  signal: AbortSignal.timeout(900000),
});
if (!res.ok) throw new Error(`HTTP ${res.status}`);
const j = await res.json();
let out = j.choices?.[0]?.message?.content ?? '';
out = out.replace(/^\s*```(?:markdown|md)?\s*/i, '').replace(/\s*```\s*$/i, '').trim();
fs.writeFileSync('everzone/posts-zh/148-戰術指揮官-未實裝內容-道具交易.md', out + '\n', 'utf8');
console.log(out);
