import fs from 'node:fs';
import path from 'node:path';

const dir = path.resolve('everzone/posts-zh');
for (const f of fs.readdirSync(dir).filter((x) => /^\d{3}-.*\.md$/.test(x))) {
  const id = Number(f.slice(0, 3));
  const q = path.join(dir, f);
  let t = fs.readFileSync(q, 'utf8');
  if (!/^lang:/m.test(t)) {
    t = t.replace('category: "戰術指揮官"', 'category: "戰術指揮官"\nlang: zh-TW');
  }
  if (!/^translated_by:/m.test(t)) {
    t = t.replace('lang: zh-TW', 'lang: zh-TW\ntranslated_by: "qwen36-35b-a3b"');
  }
  if (!/^ds_review:/m.test(t)) {
    t = t.replace(/^(translated_by: .*)$/m, '$1\nds_review: "structural_pass"');
  }
  fs.writeFileSync(q, t, 'utf8');
}
console.log('metadata updated');
