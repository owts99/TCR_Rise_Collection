import fs from 'node:fs';
import path from 'node:path';

const POSTS = path.resolve('everzone/posts');
const OUT = path.resolve('everzone/posts-zh');

const files = [
  [102, '102-택티컬-커맨더스-인간-유닛-공통-아이템.md'],
  [103, '103-택티컬-커맨더스-차량-유닛-공통-아이템.md'],
  [104, '104-택티컬-커맨더스-비행-유닛-공통-아이템.md'],
];

function bodyOf(text) {
  const i = text.indexOf('\n---', 4) + 4;
  return text.slice(i);
}

function tablesOf(body) {
  const blocks = [];
  let cur = null;
  for (const line of body.split('\n')) {
    if (line.trim().startsWith('|')) {
      if (!cur) { cur = []; blocks.push(cur); }
      cur.push(line);
    } else cur = null;
  }
  return blocks;
}

const split = (line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((s) => s.trim());
const nums = (s) => s.match(/\d+(?:\.\d+)?/g) ?? [];
const hangulOutside = (s) => /[\uAC00-\uD7A3]/.test(s.replace(/（[^）]*）/g, ''));

const errors = [];
for (const [id, srcName] of files) {
  const src = fs.readFileSync(path.join(POSTS, srcName), 'utf8');
  const outFile = fs.readdirSync(OUT).find((f) => f.startsWith(id + '-') && f.endsWith('.md'));
  const out = fs.readFileSync(path.join(OUT, outFile), 'utf8');

  if (!out.startsWith('---\n')) errors.push(`${id}: missing frontmatter`);
  if (out.includes('\uFFFD')) errors.push(`${id}: contains U+FFFD`);

  const sTables = tablesOf(bodyOf(src));
  const oTables = tablesOf(bodyOf(out));
  if (sTables.length !== oTables.length) {
    errors.push(`${id}: table count ${sTables.length} vs ${oTables.length}`);
    continue;
  }

  let sRows = 0;
  for (let t = 0; t < sTables.length; t++) {
    const s = sTables[t];
    const o = oTables[t];
    if (s.length !== o.length) {
      errors.push(`${id} table${t}: line count ${s.length} vs ${o.length}`);
      continue;
    }
    const sh = split(s[0]);
    const oh = split(o[0]);
    if (sh.length !== oh.length) errors.push(`${id} table${t}: header cols ${sh.length} vs ${oh.length}`);
    for (let r = 2; r < s.length; r++) {
      sRows++;
      const sc = split(s[r]);
      const oc = split(o[r]);
      if (sc.length !== oc.length) {
        errors.push(`${id} table${t} row${r}: cols ${sc.length} vs ${oc.length}`);
        continue;
      }
      const sn = nums(sc.join(' '));
      const on = nums(oc.join(' '));
      if (sn.join(',') !== on.join(',')) {
        errors.push(`${id} table${t} row${r}: numbers [${sn}] vs [${on}]`);
      }
      if (hangulOutside(oc[0])) {
        errors.push(`${id} table${t} row${r}: raw Hangul first cell "${oc[0]}"`);
      }
    }
  }
  console.log(`${id}: ${sTables.length} tables, ${sRows} data rows`);

  const sHeads = (bodyOf(src).match(/^#{1,3} .+$/gm) ?? []).length;
  const oHeads = (bodyOf(out).match(/^#{1,3} .+$/gm) ?? []).length;
  if (sHeads !== oHeads) errors.push(`${id}: headings ${sHeads} vs ${oHeads}`);

  let hCount = 0;
  for (const line of bodyOf(out).split('\n')) {
    if (hangulOutside(line)) {
      hCount++;
      if (hCount <= 10) errors.push(`${id}: Hangul outside parentheses: ${line.slice(0, 100)}`);
    }
  }
}

if (errors.length) {
  console.log(`\nERRORS (${errors.length}):\n` + errors.join('\n'));
  process.exit(1);
}
console.log('\nALL TRANSLATION CHECKS PASSED');
