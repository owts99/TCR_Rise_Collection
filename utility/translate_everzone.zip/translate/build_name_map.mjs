import fs from 'node:fs';
import path from 'node:path';

const BASE = 'http://127.0.0.1:8090/v1';
const MODEL = 'qwen36-35b-a3b';
const POSTS = path.resolve('everzone/posts');
const WORK = path.resolve('everzone/translate/_work_posts_zh');
fs.mkdirSync(WORK, { recursive: true });

const files = [
  '102-택티컬-커맨더스-인간-유닛-공통-아이템.md',
  '103-택티컬-커맨더스-차량-유닛-공통-아이템.md',
  '104-택티컬-커맨더스-비행-유닛-공통-아이템.md',
];

const names = [];
for (const f of files) {
  const text = fs.readFileSync(path.join(POSTS, f), 'utf8');
  for (const line of text.split('\n')) {
    const m = line.match(/^\| ([^|]+) \|/);
    if (!m) continue;
    const n = m[1].trim();
    if (n === '이름' || /^---/.test(n)) continue;
    if (!names.includes(n)) names.push(n);
  }
}
console.log(`unique names: ${names.length}`);

async function chat(prompt, maxTokens) {
  const body = {
    model: MODEL,
    messages: [
      { role: 'system', content: '你是遊戲在地化譯者，只輸出 TSV，不要說明。' },
      { role: 'user', content: prompt },
    ],
    temperature: 0,
    top_p: 1,
    max_tokens: maxTokens,
    stream: false,
  };
  const res = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(600000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${(await res.text()).slice(0, 300)}`);
  const j = await res.json();
  return j.choices?.[0]?.message?.content ?? '';
}

const promptFor = (chunk) => `你是遊戲在地化譯者。把以下韓國遊戲《Tactical Commanders》的裝備名稱翻成台灣繁體中文。
只輸出「韓文原名<TAB>中文譯名」，一行一筆，不要編號、不要說明、不要 code fence。

規則：
- 每個名稱都要能區分，同一系列用相同前綴。
- 長度 2–10 個中文字為主，不要保留韓文。
- 後綴：센서=感測器、엔진=引擎、기어=齒輪、베스트=背心、아머=裝甲、플레이트=裝甲板、셀=電池、와트=瓦特、전지=電池、리액터=反應爐、볼티지=電壓、부스터=推進器、플렛=板甲、워크=護甲、테트라=四元、블라인드=盲區。
- 例：비쥬얼센서=視覺感測器、비젼가글센서=視覺護目感測器、비젼센서=視覺強化感測器。
- 不要加括號、不要加英文。

名稱：
${chunk.join('\n')}`;

const map = {};
for (let i = 0; i < names.length; i += 60) {
  const chunk = names.slice(i, i + 60);
  console.log(`batch ${i / 60 + 1}: ${chunk.length}`);
  let text = '';
  for (let attempt = 1; attempt <= 3; attempt++) {
    text = await chat(promptFor(chunk), 3500);
    const got = chunk.filter((n) => text.includes(n + '\t'));
    console.log(`  attempt ${attempt}: ${got.length}/${chunk.length}`);
    if (got.length === chunk.length) break;
  }
  for (const line of text.split('\n')) {
    const m = line.match(/^([^\t]+)\t(.+)$/);
    if (!m) continue;
    const ko = m[1].trim();
    const zh = m[2].trim();
    if (names.includes(ko) && !map[ko]) map[ko] = zh;
  }
}

const missing = names.filter((n) => !map[n]);
console.log(`mapped: ${Object.keys(map).length}/${names.length}, missing: ${missing.length}`);
if (missing.length) console.log('MISSING:\n' + missing.join('\n'));

fs.writeFileSync(path.join(WORK, 'name_map.json'), JSON.stringify(map, null, 2), 'utf8');
const tsv = names.map((n) => `${n}\t${map[n] ?? ''}`).join('\n');
fs.writeFileSync(path.join(WORK, 'name_map.tsv'), tsv + '\n', 'utf8');
console.log('wrote name_map.json / name_map.tsv');
