import fs from 'node:fs';
import path from 'node:path';

const dir = path.resolve('everzone/posts-zh');
const add = [
  'reviewed_by: "qwen36-35b-a3b"',
  'review_confidence: 95',
  'review_verdict: "needs_fix"',
  'ds_review: "pass_after_minor_fixes"',
].join('\n');

for (const f of fs.readdirSync(dir).filter((x) => /^10[6-9]-/.test(x))) {
  const q = path.join(dir, f);
  let t = fs.readFileSync(q, 'utf8');
  if (!t.includes('reviewed_by:')) {
    t = t.replace('translated_by: "Spark-X2.5-4B"', `translated_by: "Spark-X2.5-4B"\n${add}`);
    fs.writeFileSync(q, t, 'utf8');
  }
  console.log(f);
}
