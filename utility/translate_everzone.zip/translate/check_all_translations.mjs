import fs from 'node:fs';
import path from 'node:path';

const POSTS = path.resolve('everzone/posts');
const OUT = path.resolve('everzone/posts-zh');

function bodyOf(text) {
  const m = text.match(/^---\r?\n[\s\S]*?\r?\n---\r?\n/);
  return m ? text.slice(m[0].length) : null;
}
function tablesOf(body) {
  const blocks = [];
  let cur = null;
  for (const line of body.split('\n')) {
    if (line.trim().startsWith('|')) {
      if (!cur) { cur = []; blocks.push(cur); }
      cur.push(line);
    } else cur = null;
  }
  return blocks;
}
const split = (line) => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((s) => s.trim());
const nums = (s) => s.match(/\d+(?:\.\d+)?/g) ?? [];
const hangulOutside = (s) => /[\uAC00-\uD7A3]/.test(s.replace(/（[^）]*）/g, ''));

const errors = [];
const files = fs.readdirSync(OUT).filter((f) => /^\d{3}-.*\.md$/.test(f)).sort();
let totalRows = 0;
for (const outFile of files) {
  const id = outFile.slice(0, 3);
  const srcFile = fs.readdirSync(POSTS).find((f) => f.startsWith(id + '-') && f.endsWith('.md'));
  if (!srcFile) { errors.push(`${outFile}: no source`); continue; }
  const src = fs.readFileSync(path.join(POSTS, srcFile), 'utf8');
  const out = fs.readFileSync(path.join(OUT, outFile), 'utf8');
  const sBody = bodyOf(src);
  const oBody = bodyOf(out);
  if (!oBody) { errors.push(`${outFile}: bad frontmatter`); continue; }
  if (out.includes('\uFFFD')) errors.push(`${outFile}: U+FFFD`);

  const sTables = tablesOf(sBody);
  const oTables = tablesOf(oBody);
  if (sTables.length !== oTables.length) {
    errors.push(`${outFile}: tables ${sTables.length} vs ${oTables.length}`);
    continue;
  }
  let rows = 0;
  for (let t = 0; t < sTables.length; t++) {
    const s = sTables[t];
    const o = oTables[t];
    if (s.length !== o.length) {
      errors.push(`${outFile} table${t}: lines ${s.length} vs ${o.length}`);
      continue;
    }
    const hc = split(o[0]).length;
    if (split(s[0]).length !== hc) errors.push(`${outFile} table${t}: header cols`);
    for (let r = 0; r < o.length; r++) {
      if (split(o[r]).length !== hc) errors.push(`${outFile} table${t} line${r}: cols ${split(o[r]).length} != ${hc}`);
    }
    for (let r = 2; r < s.length; r++) {
      rows++;
      const sc = split(s[r]);
      const oc = split(o[r]);
      if (sc.length !== oc.length) {
        errors.push(`${outFile} table${t} row${r}: cols ${sc.length} vs ${oc.length}`);
        continue;
      }
      const scData = sc.slice(1).join(' ');
      const ocData = oc.slice(1).join(' ');
      if (nums(scData).join(',') !== nums(ocData).join(',')) {
        errors.push(`${outFile} table${t} row${r}: numbers [${nums(scData)}] vs [${nums(ocData)}]`);
      }
      if (hangulOutside(oc[0])) errors.push(`${outFile} table${t} row${r}: raw Hangul first cell "${oc[0]}"`);
      for (let c = 1; c < oc.length; c++) {
        if (hangulOutside(oc[c])) errors.push(`${outFile} table${t} row${r} col${c}: raw Hangul "${oc[c]}"`);
      }
    }
  }
  totalRows += rows;

  let h = 0;
  for (const line of oBody.split('\n')) {
    if (hangulOutside(line)) { h++; if (h <= 3) errors.push(`${outFile}: Hangul outside: ${line.slice(0, 100)}`); }
  }
}
console.log(`files: ${files.length}, data rows: ${totalRows}`);
if (errors.length) {
  console.log(`ERRORS (${errors.length}):\n` + errors.slice(0, 80).join('\n'));
  process.exit(1);
}
console.log('ALL CHECKS PASSED');
